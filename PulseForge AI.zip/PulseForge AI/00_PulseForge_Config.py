# Databricks notebook source
# DBTITLE 1,PulseForge shared configuration
# PulseForge AI - shared configuration, source registry, logging and audit helpers.
# Used by every layer notebook via: %run ./00_PulseForge_Config
import logging, uuid
from datetime import datetime
from pyspark.sql import functions as F
from pyspark.sql import types as T

CATALOG = "team_1"
SCHEMA = "default"                                        # holds only the source + state volumes
SOURCE_PATH = "/Volumes/team_1/default/pulseforge/PulseForge"
STATE_VOLUME = "pf_pipeline_state"                       # Auto Loader schemas + checkpoints (do not rename: holds stream state)
STATE_ROOT = f"/Volumes/{CATALOG}/{SCHEMA}/{STATE_VOLUME}"

# One schema per layer: team_1.bronze / team_1.silver / team_1.gold / team_1.dashboard (+ team_1.ops for pipeline metadata).
# Table names are the plain entity name, e.g. team_1.bronze.jira_issues, team_1.gold.employee_360, team_1.dashboard.mv_employee_360.
BRONZE_PREFIX, SILVER_PREFIX, GOLD_PREFIX, MV_PREFIX = "bronze.", "silver.", "gold.", "dashboard.mv_"
AUDIT_TABLE = f"{CATALOG}.ops.pipeline_audit_log"
WATERMARK_TABLE = f"{CATALOG}.ops.pipeline_watermarks"
DQ_TABLE = f"{CATALOG}.silver.dq_results"

def fq(name: str) -> str:
    """'bronze.jira_issues' -> 'team_1.bronze.jira_issues' (schema-qualified names are used as is)."""
    return f"{CATALOG}.{name}" if "." in name else f"{CATALOG}.{SCHEMA}.{name}"

# Source registry: file name (without .csv) -> source system, business key, expected columns (validated in Bronze).
SOURCES = {
    "hr4u_employees": {"system": "HR4U", "pk": ["employee_id"], "columns": ["employee_id","employee_name","email","department_id","department_name","business_unit","job_title","job_level","manager_id","manager_name","location","country","employment_type","joining_date","employment_status","experience_years","cost_center","last_updated_date"]},
    "hr4u_employee_goals": {"system": "HR4U", "pk": ["goal_id"], "columns": ["goal_id","employee_id","goal_title","goal_description","goal_category","start_date","target_date","completion_percentage","goal_status","manager_id","last_updated_date"]},
    "hr4u_employee_mobility": {"system": "HR4U", "pk": ["mobility_id"], "columns": ["mobility_id","employee_id","current_department","previous_department","current_role","previous_role","mobility_type","effective_date","career_interest","target_role","mobility_status"]},
    "hr4u_performance_reviews": {"system": "HR4U", "pk": ["review_id"], "columns": ["review_id","employee_id","reviewer_id","review_period","review_date","overall_rating","goal_achievement_score","collaboration_score","delivery_score","strengths","improvement_areas","manager_feedback","review_status"]},
    "jira_issues": {"system": "Jira", "pk": ["issue_id"], "columns": ["issue_id","issue_key","project_id","project_name","summary","description","issue_type","priority","status","assignee_id","assignee_name","reporter_id","created_date","updated_date","due_date","resolved_date","story_points","sprint_id","labels","resolution"]},
    "jira_sprints": {"system": "Jira", "pk": ["sprint_id"], "columns": ["sprint_id","sprint_name","project_id","start_date","end_date","sprint_status","committed_story_points","completed_story_points"]},
    "jira_worklogs": {"system": "Jira", "pk": ["worklog_id"], "columns": ["worklog_id","issue_id","employee_id","employee_name","work_date","time_spent_hours","work_description","created_date"]},
    "lms_courses": {"system": "LMS", "pk": ["course_id"], "columns": ["course_id","course_name","course_category","course_description","skill_name","difficulty_level","course_duration_hours","provider","mandatory_flag","course_status"]},
    "lms_learning_activity": {"system": "LMS", "pk": ["learning_activity_id"], "columns": ["learning_activity_id","employee_id","course_id","enrollment_date","start_date","completion_date","learning_status","progress_percentage","learning_hours","assessment_score","pass_status","last_activity_date"]},
    "lms_certifications": {"system": "LMS", "pk": ["certification_id"], "columns": ["certification_id","employee_id","certification_name","certification_provider","skill_category","issue_date","expiry_date","certification_status","credential_id","verification_status"]},
    "servicenow_incidents": {"system": "ServiceNow", "pk": ["incident_id"], "columns": ["incident_id","employee_id","employee_name","assigned_to_id","assigned_to_name","assignment_group","category","subcategory","short_description","description","priority","urgency","impact","state","opened_date","resolved_date","closed_date","resolution_time_hours","reopen_count","sla_status","satisfaction_score"]},
    "servicenow_requests": {"system": "ServiceNow", "pk": ["request_id"], "columns": ["request_id","employee_id","request_type","request_category","requested_item","assigned_group","assigned_to_id","request_status","request_date","approval_status","completion_date","fulfillment_time_hours"]},
    "servicenow_tasks": {"system": "ServiceNow", "pk": ["task_id"], "columns": ["task_id","parent_request_id","assigned_to_id","employee_id","task_type","task_status","priority","created_date","completed_date","work_notes"]},
    # Added by synthetic batch 01 to close data gaps (see 05_PulseForge_Synthetic_Data_Generator)
    "hr4u_employee_skills": {"system": "HR4U", "pk": ["employee_skill_id"], "columns": ["employee_skill_id","employee_id","skill_name","skill_category","proficiency_level","proficiency_score","experience_years","last_assessed_date","assessment_source","last_updated_date"]},
    "hr4u_role_skill_requirements": {"system": "HR4U", "pk": ["requirement_id"], "columns": ["requirement_id","role_name","skill_name","skill_category","required_proficiency_level","required_proficiency_score","importance","framework","last_updated_date"]},
    "hr4u_manager_access": {"system": "HR4U", "pk": ["access_id"], "columns": ["access_id","user_email","manager_employee_id","access_role","access_scope","valid_from","valid_to","granted_by"]},
}

# Business event date per source, used by the data freshness table in Gold.
BUSINESS_DATE = {
    "hr4u_employees": "last_updated_date", "hr4u_employee_goals": "last_updated_date", "hr4u_employee_mobility": "effective_date",
    "hr4u_performance_reviews": "review_date", "hr4u_employee_skills": "last_assessed_date", "hr4u_role_skill_requirements": "last_updated_date",
    "hr4u_manager_access": "valid_from", "jira_issues": "updated_date", "jira_sprints": "end_date", "jira_worklogs": "work_date",
    "lms_courses": None, "lms_learning_activity": "last_activity_date", "lms_certifications": "issue_date",
    "servicenow_incidents": "opened_date", "servicenow_requests": "request_date", "servicenow_tasks": "created_date",
}

# ---------- logging ----------
logger = logging.getLogger("pulseforge")
if not logger.handlers:
    _h = logging.StreamHandler()
    _h.setFormatter(logging.Formatter("%(asctime)s | %(levelname)s | %(message)s"))
    logger.addHandler(_h)
logger.setLevel(logging.INFO)

# ---------- audit + watermark tables ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS {AUDIT_TABLE} (
  run_id STRING, layer STRING, entity STRING, status STRING, rows_processed BIGINT,
  started_at TIMESTAMP, ended_at TIMESTAMP, message STRING)
COMMENT 'PulseForge pipeline audit log: one row per layer/entity/run with status and row counts.'""")
spark.sql(f"""CREATE TABLE IF NOT EXISTS {WATERMARK_TABLE} (
  entity STRING, last_bronze_ingest_ts TIMESTAMP, updated_at TIMESTAMP)
COMMENT 'PulseForge incremental watermarks: last Bronze _ingest_ts consumed by Silver per entity.'""")

_AUDIT_SCHEMA = T.StructType([
    T.StructField("run_id", T.StringType()), T.StructField("layer", T.StringType()),
    T.StructField("entity", T.StringType()), T.StructField("status", T.StringType()),
    T.StructField("rows_processed", T.LongType()), T.StructField("started_at", T.TimestampType()),
    T.StructField("ended_at", T.TimestampType()), T.StructField("message", T.StringType())])

def log_audit(run_id, layer, entity, status, rows, started_at, message=""):
    row = [(run_id, layer, entity, status, None if rows is None else int(rows), started_at, datetime.now(), (message or "")[:4000])]
    spark.createDataFrame(row, _AUDIT_SCHEMA).write.mode("append").saveAsTable(AUDIT_TABLE)
    logger.info(f"[{layer}] {entity}: {status} rows={rows} {message[:200] if message else ''}")

def new_run_id() -> str:
    return datetime.now().strftime("%Y%m%d%H%M%S") + "-" + uuid.uuid4().hex[:8]

logger.info(f"PulseForge config loaded: {CATALOG}.{SCHEMA}, source={SOURCE_PATH}, {len(SOURCES)} sources")
