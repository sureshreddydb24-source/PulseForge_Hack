# Databricks notebook source
# DBTITLE 1,Bronze layer overview
# MAGIC %md
# MAGIC # PulseForge AI - Bronze ingestion
# MAGIC Ingests the 13 HR4U, Jira, ServiceNow and LMS CSV files from `/Volumes/team_1/default/pulseforge/PulseForge` into append-only Delta tables `team_1.bronze.<source>`.
# MAGIC
# MAGIC * **Incremental**: Auto Loader (`cloudFiles`) with `availableNow` trigger and per-source checkpoints - only new or overwritten files are processed.
# MAGIC * **Raw preservation**: every column kept as STRING; unexpected columns land in `_rescued_data`; nothing is updated or deleted, so every load is kept as history.
# MAGIC * **Metadata**: `_source_system`, `_source_entity`, `_source_file`, `_source_file_mod_ts`, `_ingest_ts`, `_batch_id`.
# MAGIC * **Schema validation**: file headers are checked against the expected columns in the config registry before loading.
# MAGIC * **Audit**: one row per source and run in `team_1.ops.pipeline_audit_log`.

# COMMAND ----------

# DBTITLE 1,Load shared config
# MAGIC %run ./00_PulseForge_Config

# COMMAND ----------

# DBTITLE 1,Run setup and state volume
dbutils.widgets.text("run_id", "", "Run ID (blank = new)")
RUN_ID = dbutils.widgets.get("run_id") or new_run_id()
spark.sql(f"CREATE VOLUME IF NOT EXISTS {CATALOG}.{SCHEMA}.{STATE_VOLUME} COMMENT 'PulseForge Auto Loader schema and checkpoint state'")
logger.info(f"Bronze run {RUN_ID} starting")

# COMMAND ----------

# DBTITLE 1,Schema validation and Auto Loader ingest functions
def validate_source_schema(src: str, cfg: dict) -> list:
    """Compare the CSV header with the expected column list. Missing columns fail the source; extra columns are warned and preserved via _rescued_data."""
    actual = spark.read.option("header", "true").csv(f"{SOURCE_PATH}/{src}*.csv").columns
    missing = [c for c in cfg["columns"] if c not in actual]
    extra = [c for c in actual if c not in cfg["columns"]]
    if missing:
        raise ValueError(f"{src}: missing expected columns {missing}")
    if extra:
        logger.warning(f"{src}: unexpected new columns {extra} (kept in _rescued_data)")
    return extra

def ingest_source(src: str, cfg: dict) -> int:
    target = fq(BRONZE_PREFIX + src)
    stream = (spark.readStream.format("cloudFiles")
        .option("cloudFiles.format", "csv")
        .option("header", "true")
        .option("multiLine", "true")
        .option("escape", '"')
        .option("cloudFiles.inferColumnTypes", "false")            # keep raw strings
        .option("cloudFiles.schemaEvolutionMode", "rescue")        # never fail on new columns
        .option("cloudFiles.allowOverwrites", "true")              # re-ingest a snapshot file when it is replaced
        .option("cloudFiles.schemaLocation", f"{STATE_ROOT}/schemas/{src}")
        .option("pathGlobFilter", f"{src}*.csv")
        .load(SOURCE_PATH)
        .select("*",
                F.col("_metadata.file_path").alias("_source_file"),
                F.col("_metadata.file_modification_time").alias("_source_file_mod_ts"),
                F.current_timestamp().alias("_ingest_ts"),
                F.lit(cfg["system"]).alias("_source_system"),
                F.lit(src).alias("_source_entity"),
                F.lit(RUN_ID).alias("_batch_id")))
    q = (stream.writeStream
        .option("checkpointLocation", f"{STATE_ROOT}/checkpoints/bronze_{src}")
        .option("mergeSchema", "true")
        .trigger(availableNow=True)
        .toTable(target))
    q.awaitTermination()
    return spark.table(target).filter(F.col("_batch_id") == RUN_ID).count()

# COMMAND ----------

# DBTITLE 1,Ingest all sources with audit and error handling
results, failures = [], []
for src, cfg in SOURCES.items():
    started = datetime.now()
    try:
        validate_source_schema(src, cfg)
        n = ingest_source(src, cfg)
        spark.sql(f"COMMENT ON TABLE {fq(BRONZE_PREFIX + src)} IS 'Bronze raw {cfg['system']} {src} (append-only, all STRING, with ingestion metadata). Source: {SOURCE_PATH}/{src}.csv'")
        log_audit(RUN_ID, "bronze", src, "SUCCESS", n, started, "no new files" if n == 0 else "")
        results.append((src, cfg["system"], n, "SUCCESS"))
    except Exception as ex:
        log_audit(RUN_ID, "bronze", src, "FAILED", None, started, str(ex))
        results.append((src, cfg["system"], None, "FAILED"))
        failures.append((src, str(ex)[:500]))

display(spark.createDataFrame(results, "source STRING, system STRING, rows_ingested_this_run BIGINT, status STRING"))
if failures:
    raise RuntimeError(f"Bronze ingestion failed for {len(failures)} source(s): {failures}")

# COMMAND ----------

# DBTITLE 1,Bronze table totals and rescued data check
summary = []
for src in SOURCES:
    df = spark.table(fq(BRONZE_PREFIX + src))
    summary.append((src, df.count(), df.filter(F.col("_rescued_data").isNotNull()).count(),
                    df.select(F.countDistinct("_batch_id")).first()[0]))
display(spark.createDataFrame(summary, "bronze_table STRING, total_rows BIGINT, rows_with_rescued_data BIGINT, loads BIGINT"))