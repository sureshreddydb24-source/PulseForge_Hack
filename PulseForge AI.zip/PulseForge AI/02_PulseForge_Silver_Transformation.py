# Databricks notebook source
# DBTITLE 1,Silver layer overview
# MAGIC %md
# MAGIC # PulseForge AI - Silver transformation
# MAGIC Turns Bronze raw tables into cleansed, typed and integrated tables `team_1.silver.<source>`. Silver reads only `team_1.bronze` tables.
# MAGIC
# MAGIC * **Incremental**: only Bronze rows with `_ingest_ts` after the last watermark (`team_1.ops.pipeline_watermarks`) are processed, then MERGEd on the business key. Rows update only when their content hash (`_row_hash`) changes.
# MAGIC * **Duplicates**: rows with a null business key are dropped and counted; the latest version per key wins (by file modification time, then ingest time).
# MAGIC * **Standardisation**: trimmed and upper-cased IDs, typed dates and timestamps, harmonised status flags (`status_category`, `is_resolved`, `is_open`, `is_completed`), derived missing values (for example, `resolution_time_hours` from timestamps).
# MAGIC * **History**: `silver.hr4u_employees_scd2` keeps employee attribute history as SCD Type 2.
# MAGIC * **Identity resolution**: `silver.employee_identity_map` validates every person-ID column in Jira, ServiceNow, LMS and HR4U against the HR4U `employee_id`, including whether the names match.
# MAGIC * **Data quality**: results are written to `silver.dq_results`; any CRITICAL failure stops the run.

# COMMAND ----------

# DBTITLE 1,Load shared config
# MAGIC %run ./00_PulseForge_Config

# COMMAND ----------

# DBTITLE 1,Run setup
from pyspark.sql.window import Window
dbutils.widgets.text("run_id", "", "Run ID (blank = new)")
RUN_ID = dbutils.widgets.get("run_id") or new_run_id()
META = "_source_system, _source_file, _ingest_ts AS _bronze_ingest_ts, _batch_id AS _bronze_batch_id, _source_file LIKE '%synthetic%' AS _is_synthetic"
logger.info(f"Silver run {RUN_ID} starting")

# COMMAND ----------

# DBTITLE 1,Silver cleansing and standardisation rules per source
# One SELECT per source. {v} = deduplicated Bronze increment, {meta} = lineage columns.
TRANSFORMS = {
"hr4u_employees": """
SELECT upper(trim(employee_id)) AS employee_id, trim(employee_name) AS employee_name, lower(trim(email)) AS email,
  upper(trim(department_id)) AS department_id, trim(department_name) AS department_name, trim(business_unit) AS business_unit,
  trim(job_title) AS job_title, upper(trim(job_level)) AS job_level,
  upper(nullif(trim(manager_id), '')) AS manager_id, nullif(trim(manager_name), '') AS manager_name,
  trim(location) AS location, trim(country) AS country, trim(employment_type) AS employment_type,
  try_cast(joining_date AS DATE) AS joining_date, initcap(trim(employment_status)) AS employment_status,
  try_cast(experience_years AS DECIMAL(5,1)) AS experience_years, trim(cost_center) AS cost_center,
  try_cast(last_updated_date AS TIMESTAMP) AS last_updated_date,
  concat(trim(employee_name), ' | ', upper(trim(employee_id))) AS employee_display_name, {meta}
FROM {v}""",
"hr4u_employee_goals": """
SELECT upper(trim(goal_id)) AS goal_id, upper(trim(employee_id)) AS employee_id, trim(goal_title) AS goal_title,
  trim(goal_description) AS goal_description, trim(goal_category) AS goal_category,
  try_cast(start_date AS DATE) AS start_date, try_cast(target_date AS DATE) AS target_date,
  least(greatest(try_cast(completion_percentage AS DECIMAL(5,2)), 0), 100) AS completion_percentage,
  trim(goal_status) AS goal_status, upper(nullif(trim(manager_id), '')) AS manager_id,
  try_cast(last_updated_date AS DATE) AS last_updated_date,
  concat(year(try_cast(start_date AS DATE)), '-H', IF(month(try_cast(start_date AS DATE)) <= 6, 1, 2)) AS goal_period, {meta}
FROM {v}""",
"hr4u_employee_mobility": """
SELECT upper(trim(mobility_id)) AS mobility_id, upper(trim(employee_id)) AS employee_id,
  trim(current_department) AS current_department, trim(previous_department) AS previous_department,
  trim(current_role) AS current_role, trim(previous_role) AS previous_role, trim(mobility_type) AS mobility_type,
  try_cast(effective_date AS DATE) AS effective_date, trim(career_interest) AS career_interest,
  trim(target_role) AS target_role, trim(mobility_status) AS mobility_status, {meta}
FROM {v}""",
"hr4u_performance_reviews": """
SELECT upper(trim(review_id)) AS review_id, upper(trim(employee_id)) AS employee_id, upper(trim(reviewer_id)) AS reviewer_id,
  upper(trim(review_period)) AS review_period, try_cast(review_date AS DATE) AS review_date,
  try_cast(overall_rating AS DECIMAL(4,2)) AS overall_rating, try_cast(goal_achievement_score AS DECIMAL(4,2)) AS goal_achievement_score,
  try_cast(collaboration_score AS DECIMAL(4,2)) AS collaboration_score, try_cast(delivery_score AS DECIMAL(4,2)) AS delivery_score,
  trim(strengths) AS strengths, trim(improvement_areas) AS improvement_areas, nullif(trim(manager_feedback), '') AS manager_feedback,
  trim(review_status) AS review_status, {meta}
FROM {v}""",
"jira_issues": """
SELECT trim(issue_id) AS issue_id, upper(trim(issue_key)) AS issue_key, trim(project_id) AS project_id, trim(project_name) AS project_name,
  trim(summary) AS summary, trim(description) AS description, trim(issue_type) AS issue_type, trim(priority) AS priority,
  trim(status) AS status,
  CASE WHEN lower(trim(status)) IN ('done','closed','resolved') THEN 'Done'
       WHEN lower(trim(status)) IN ('to do','open','backlog','new') THEN 'To Do'
       ELSE 'In Progress' END AS status_category,
  lower(trim(status)) = 'blocked' AS is_blocked,
  upper(trim(assignee_id)) AS assignee_id, trim(assignee_name) AS assignee_name, upper(trim(reporter_id)) AS reporter_id,
  try_cast(created_date AS DATE) AS created_date, try_cast(updated_date AS DATE) AS updated_date,
  try_cast(due_date AS DATE) AS due_date, try_cast(resolved_date AS DATE) AS resolved_date,
  coalesce(try_cast(story_points AS DECIMAL(10,2)), 0) AS story_points, upper(trim(sprint_id)) AS sprint_id,
  trim(labels) AS labels, split(trim(labels), ';') AS label_list, trim(resolution) AS resolution, {meta}
FROM {v}""",
"jira_sprints": """
SELECT upper(trim(sprint_id)) AS sprint_id, trim(sprint_name) AS sprint_name, trim(project_id) AS project_id,
  try_cast(start_date AS DATE) AS start_date, try_cast(end_date AS DATE) AS end_date, trim(sprint_status) AS sprint_status,
  try_cast(committed_story_points AS DECIMAL(10,2)) AS committed_story_points,
  try_cast(completed_story_points AS DECIMAL(10,2)) AS completed_story_points, {meta}
FROM {v}""",
"jira_worklogs": """
SELECT trim(worklog_id) AS worklog_id, trim(issue_id) AS issue_id, upper(trim(employee_id)) AS employee_id,
  trim(employee_name) AS employee_name, try_cast(work_date AS DATE) AS work_date,
  try_cast(time_spent_hours AS DECIMAL(6,2)) AS time_spent_hours, trim(work_description) AS work_description,
  try_cast(created_date AS DATE) AS created_date,
  dayofweek(try_cast(work_date AS DATE)) IN (1, 7) AS is_weekend,
  -- work_start_time only exists in newer files; Auto Loader keeps it in _rescued_data (schema evolution in rescue mode)
  try_cast(get_json_object(_rescued_data, '$.work_start_time') AS TIMESTAMP) AS work_start_time,
  CASE WHEN try_cast(get_json_object(_rescued_data, '$.work_start_time') AS TIMESTAMP) IS NULL THEN NULL
       ELSE hour(try_cast(get_json_object(_rescued_data, '$.work_start_time') AS TIMESTAMP)) < 8
         OR hour(try_cast(get_json_object(_rescued_data, '$.work_start_time') AS TIMESTAMP)) >= 19 END AS is_after_hours, {meta}
FROM {v}""",
"lms_courses": """
SELECT upper(trim(course_id)) AS course_id, trim(course_name) AS course_name, trim(course_category) AS course_category,
  trim(course_description) AS course_description, trim(skill_name) AS skill_name, trim(difficulty_level) AS difficulty_level,
  try_cast(course_duration_hours AS DECIMAL(6,2)) AS course_duration_hours, trim(provider) AS provider,
  lower(trim(mandatory_flag)) = 'mandatory' AS is_mandatory, trim(course_status) AS course_status, {meta}
FROM {v}""",
"lms_learning_activity": """
SELECT upper(trim(learning_activity_id)) AS learning_activity_id, upper(trim(employee_id)) AS employee_id,
  upper(trim(course_id)) AS course_id, try_cast(enrollment_date AS DATE) AS enrollment_date,
  try_cast(start_date AS DATE) AS start_date, try_cast(completion_date AS DATE) AS completion_date,
  trim(learning_status) AS learning_status,
  CASE WHEN trim(learning_status) = 'Completed' THEN coalesce(try_cast(progress_percentage AS DECIMAL(5,2)), 100)
       ELSE coalesce(try_cast(progress_percentage AS DECIMAL(5,2)), 0) END AS progress_percentage,
  coalesce(try_cast(learning_hours AS DECIMAL(6,2)), 0) AS learning_hours,
  try_cast(assessment_score AS DECIMAL(5,2)) AS assessment_score, trim(pass_status) AS pass_status,
  try_cast(last_activity_date AS DATE) AS last_activity_date, {meta}
FROM {v}""",
"lms_certifications": """
SELECT upper(trim(certification_id)) AS certification_id, upper(trim(employee_id)) AS employee_id,
  trim(certification_name) AS certification_name, trim(certification_provider) AS certification_provider,
  trim(skill_category) AS skill_category, try_cast(issue_date AS DATE) AS issue_date, try_cast(expiry_date AS DATE) AS expiry_date,
  trim(certification_status) AS certification_status, nullif(trim(credential_id), '') AS credential_id,
  trim(verification_status) AS verification_status, {meta}
FROM {v}""",
"servicenow_incidents": """
SELECT upper(trim(incident_id)) AS incident_id, upper(trim(employee_id)) AS employee_id, trim(employee_name) AS employee_name,
  upper(nullif(trim(assigned_to_id), '')) AS assigned_to_id, nullif(trim(assigned_to_name), '') AS assigned_to_name,
  trim(assignment_group) AS assignment_group, trim(category) AS category, trim(subcategory) AS subcategory,
  trim(short_description) AS short_description, trim(description) AS description, trim(priority) AS priority,
  trim(urgency) AS urgency, trim(impact) AS impact, trim(state) AS state,
  try_cast(opened_date AS TIMESTAMP) AS opened_date, try_cast(resolved_date AS TIMESTAMP) AS resolved_date,
  try_cast(closed_date AS TIMESTAMP) AS closed_date,
  coalesce(try_cast(resolution_time_hours AS DECIMAL(10,2)),
           CAST(round((unix_timestamp(try_cast(resolved_date AS TIMESTAMP)) - unix_timestamp(try_cast(opened_date AS TIMESTAMP))) / 3600.0, 2) AS DECIMAL(10,2))) AS resolution_time_hours,
  coalesce(try_cast(reopen_count AS INT), 0) AS reopen_count, coalesce(nullif(trim(sla_status), ''), 'Unknown') AS sla_status,
  try_cast(satisfaction_score AS DECIMAL(3,1)) AS satisfaction_score,
  trim(state) IN ('Resolved', 'Closed') AS is_resolved,
  trim(state) IN ('New', 'In Progress', 'On Hold', 'Assigned') AS is_open,
  (hour(try_cast(opened_date AS TIMESTAMP)) < 8 OR hour(try_cast(opened_date AS TIMESTAMP)) >= 19
     OR dayofweek(try_cast(opened_date AS TIMESTAMP)) IN (1, 7)) AS is_after_hours, {meta}
FROM {v}""",
"servicenow_requests": """
SELECT upper(trim(request_id)) AS request_id, upper(trim(employee_id)) AS employee_id, trim(request_type) AS request_type,
  trim(request_category) AS request_category, trim(requested_item) AS requested_item, trim(assigned_group) AS assigned_group,
  upper(nullif(trim(assigned_to_id), '')) AS assigned_to_id, trim(request_status) AS request_status,
  try_cast(request_date AS TIMESTAMP) AS request_date, trim(approval_status) AS approval_status,
  try_cast(completion_date AS TIMESTAMP) AS completion_date,
  coalesce(try_cast(fulfillment_time_hours AS DECIMAL(10,2)),
           CAST(round((unix_timestamp(try_cast(completion_date AS TIMESTAMP)) - unix_timestamp(try_cast(request_date AS TIMESTAMP))) / 3600.0, 2) AS DECIMAL(10,2))) AS fulfillment_time_hours,
  trim(request_status) = 'Closed Complete' AS is_completed,
  trim(request_status) IN ('Work in Progress', 'Pending Approval', 'Open', 'New') AS is_open, {meta}
FROM {v}""",
"servicenow_tasks": """
SELECT upper(trim(task_id)) AS task_id, upper(trim(parent_request_id)) AS parent_request_id,
  upper(nullif(trim(assigned_to_id), '')) AS assigned_to_id, upper(trim(employee_id)) AS employee_id,
  trim(task_type) AS task_type, trim(task_status) AS task_status, trim(priority) AS priority,
  try_cast(created_date AS TIMESTAMP) AS created_date, try_cast(completed_date AS TIMESTAMP) AS completed_date,
  trim(work_notes) AS work_notes, trim(task_status) = 'Closed Complete' AS is_completed,
  trim(task_status) IN ('Open', 'Work in Progress', 'Pending') AS is_open, {meta}
FROM {v}""",
"hr4u_employee_skills": """
SELECT upper(trim(employee_skill_id)) AS employee_skill_id, upper(trim(employee_id)) AS employee_id, trim(skill_name) AS skill_name,
  trim(skill_category) AS skill_category, initcap(trim(proficiency_level)) AS proficiency_level,
  try_cast(proficiency_score AS INT) AS proficiency_score, try_cast(experience_years AS DECIMAL(5,1)) AS experience_years,
  try_cast(last_assessed_date AS DATE) AS last_assessed_date, trim(assessment_source) AS assessment_source,
  try_cast(last_updated_date AS DATE) AS last_updated_date, {meta}
FROM {v}""",
"hr4u_role_skill_requirements": """
SELECT upper(trim(requirement_id)) AS requirement_id, trim(role_name) AS role_name, trim(skill_name) AS skill_name,
  trim(skill_category) AS skill_category, initcap(trim(required_proficiency_level)) AS required_proficiency_level,
  try_cast(required_proficiency_score AS INT) AS required_proficiency_score, trim(importance) AS importance,
  trim(framework) AS framework, try_cast(last_updated_date AS DATE) AS last_updated_date, {meta}
FROM {v}""",
"hr4u_manager_access": """
SELECT upper(trim(access_id)) AS access_id, lower(trim(user_email)) AS user_email, upper(trim(manager_employee_id)) AS manager_employee_id,
  upper(trim(access_role)) AS access_role, upper(trim(access_scope)) AS access_scope,
  try_cast(valid_from AS DATE) AS valid_from, try_cast(nullif(trim(valid_to), '') AS DATE) AS valid_to,
  trim(granted_by) AS granted_by, {meta}
FROM {v}""",
}
assert set(TRANSFORMS) == set(SOURCES), "Every registered source needs a Silver transform"

# COMMAND ----------

# DBTITLE 1,Incremental dedup and MERGE function
def get_watermark(src):
    rows = spark.table(WATERMARK_TABLE).filter(F.col("entity") == src).select("last_bronze_ingest_ts").collect()
    return rows[0][0] if rows else None

def set_watermark(src, ts):
    spark.createDataFrame([(src, ts)], "entity STRING, ts TIMESTAMP").createOrReplaceTempView("pf_tmp_wm")
    spark.sql(f"""MERGE INTO {WATERMARK_TABLE} t USING pf_tmp_wm s ON t.entity = s.entity
      WHEN MATCHED THEN UPDATE SET last_bronze_ingest_ts = s.ts, updated_at = current_timestamp()
      WHEN NOT MATCHED THEN INSERT (entity, last_bronze_ingest_ts, updated_at) VALUES (s.entity, s.ts, current_timestamp())""")

def process_entity(src: str) -> dict:
    pk = SOURCES[src]["pk"]
    tgt = fq(SILVER_PREFIX + src)
    # Keep the synthetic flag present on every Silver table, even when no new Bronze rows arrive
    if spark.catalog.tableExists(tgt) and "_is_synthetic" not in spark.table(tgt).columns:
        spark.sql(f"ALTER TABLE {tgt} ADD COLUMN _is_synthetic BOOLEAN COMMENT 'true when the row came from a *_synthetic_* source file'")
        spark.sql(f"UPDATE {tgt} SET _is_synthetic = _source_file LIKE '%synthetic%'")
    bronze = spark.table(fq(BRONZE_PREFIX + src))
    wm = get_watermark(src)
    inc = bronze if wm is None else bronze.filter(F.col("_ingest_ts") > F.lit(wm))
    rows_in = inc.count()
    if rows_in == 0:
        return {"rows_in": 0, "rows_out": 0, "null_keys": 0, "duplicates": 0}
    new_wm = inc.agg(F.max("_ingest_ts")).first()[0]

    keyed = inc.select("*", *[F.upper(F.trim(F.col(c))).alias(f"_k_{c}") for c in pk])
    null_cond = " OR ".join(f"_k_{c} IS NULL" for c in pk)
    null_keys = keyed.filter(null_cond).count()
    w = Window.partitionBy(*[f"_k_{c}" for c in pk]).orderBy(F.col("_source_file_mod_ts").desc(), F.col("_ingest_ts").desc())
    latest = (keyed.filter(f"NOT ({null_cond})").withColumn("_rn", F.row_number().over(w))
              .filter("_rn = 1").drop("_rn", *[f"_k_{c}" for c in pk]))
    view = f"pf_tmp_bronze_{src}"
    latest.createOrReplaceTempView(view)
    out = spark.sql(TRANSFORMS[src].format(v=view, meta=META))
    biz_cols = [c for c in out.columns if not c.startswith("_")]
    out = (out.withColumn("_row_hash", F.sha2(F.concat_ws("||", *[F.coalesce(F.col(c).cast("string"), F.lit("<null>")) for c in biz_cols]), 256))
              .withColumn("_silver_updated_ts", F.current_timestamp()))
    rows_out = out.count()

    target = fq(SILVER_PREFIX + src)
    if not spark.catalog.tableExists(target):
        out.write.option("delta.enableChangeDataFeed", "true").saveAsTable(target)
    else:
        out.createOrReplaceTempView(f"pf_tmp_silver_{src}")
        on = " AND ".join(f"t.{c} = s.{c}" for c in pk)
        # WITH SCHEMA EVOLUTION lets new Silver columns (e.g. work_start_time, _is_synthetic) be added on merge
        spark.sql(f"""MERGE WITH SCHEMA EVOLUTION INTO {target} t USING pf_tmp_silver_{src} s ON {on}
          WHEN MATCHED AND t._row_hash <> s._row_hash THEN UPDATE SET *
          WHEN NOT MATCHED THEN INSERT *""")
    # one-time backfill of the synthetic flag for rows loaded before the flag existed (idempotent)
    spark.sql(f"UPDATE {target} SET _is_synthetic = _source_file LIKE '%synthetic%' WHERE _is_synthetic IS NULL")
    set_watermark(src, new_wm)
    return {"rows_in": rows_in, "rows_out": rows_out, "null_keys": null_keys, "duplicates": rows_in - null_keys - rows_out}

# COMMAND ----------

# DBTITLE 1,Process all sources into Silver
silver_results, failures = [], []
for src, cfg in SOURCES.items():
    started = datetime.now()
    try:
        r = process_entity(src)
        spark.sql(f"COMMENT ON TABLE {fq(SILVER_PREFIX + src)} IS 'Silver cleansed {cfg['system']} {src}: typed, deduplicated on {', '.join(cfg['pk'])}, standardised statuses. Lineage: {BRONZE_PREFIX}{src}.'")
        msg = f"null_keys={r['null_keys']} duplicates_removed={r['duplicates']}"
        log_audit(RUN_ID, "silver", src, "SUCCESS", r["rows_out"], started, msg)
        silver_results.append((src, r["rows_in"], r["rows_out"], r["null_keys"], r["duplicates"], "SUCCESS"))
    except Exception as ex:
        log_audit(RUN_ID, "silver", src, "FAILED", None, started, str(ex))
        silver_results.append((src, None, None, None, None, "FAILED"))
        failures.append((src, str(ex)[:500]))

display(spark.createDataFrame(silver_results, "source STRING, bronze_rows_in BIGINT, silver_rows_merged BIGINT, null_keys_dropped BIGINT, duplicates_removed BIGINT, status STRING"))
if failures:
    raise RuntimeError(f"Silver failed for {len(failures)} source(s): {failures}")

# COMMAND ----------

# DBTITLE 1,Employee history as SCD Type 2
SCD2_TABLE = fq(SILVER_PREFIX + "hr4u_employees_scd2")
TRACKED = ["employee_name", "department_id", "department_name", "business_unit", "job_title", "job_level",
           "manager_id", "location", "country", "employment_type", "employment_status"]
started = datetime.now()
spark.sql(f"""CREATE TABLE IF NOT EXISTS {SCD2_TABLE} (
  employee_id STRING, {', '.join(f'{c} STRING' for c in TRACKED)}, attr_hash STRING,
  effective_from TIMESTAMP, effective_to TIMESTAMP, is_current BOOLEAN, _loaded_ts TIMESTAMP)
COMMENT 'Silver SCD Type 2 employee history: one row per employee per attribute version (department, role, level, manager, location, status). is_current = latest version.'""")

spark.sql(f"""CREATE OR REPLACE TEMP VIEW pf_tmp_emp_stage AS
SELECT employee_id, {', '.join(TRACKED)},
  sha2(concat_ws('||', {', '.join(f"coalesce({c}, '<null>')" for c in TRACKED)}), 256) AS attr_hash,
  coalesce(last_updated_date, CAST(joining_date AS TIMESTAMP), current_timestamp()) AS effective_from
FROM {fq(SILVER_PREFIX + 'hr4u_employees')}""")

cols = ["employee_id"] + TRACKED + ["attr_hash", "effective_from"]
spark.sql(f"""MERGE INTO {SCD2_TABLE} t
USING (
  SELECT s.employee_id AS merge_key, s.* FROM pf_tmp_emp_stage s
  UNION ALL
  SELECT NULL AS merge_key, s.* FROM pf_tmp_emp_stage s
  JOIN {SCD2_TABLE} c ON s.employee_id = c.employee_id AND c.is_current AND c.attr_hash <> s.attr_hash
) u
ON t.employee_id = u.merge_key AND t.is_current
WHEN MATCHED AND t.attr_hash <> u.attr_hash THEN
  UPDATE SET is_current = false, effective_to = greatest(u.effective_from, t.effective_from)
WHEN NOT MATCHED THEN
  INSERT ({', '.join(cols)}, effective_to, is_current, _loaded_ts)
  VALUES ({', '.join('u.' + c for c in cols)}, NULL, true, current_timestamp())""")
n = spark.table(SCD2_TABLE).count()
log_audit(RUN_ID, "silver", "hr4u_employees_scd2", "SUCCESS", n, started)
display(spark.sql(f"SELECT is_current, count(*) AS versions, count(DISTINCT employee_id) AS employees FROM {SCD2_TABLE} GROUP BY is_current"))

# COMMAND ----------

# DBTITLE 1,Employee identity resolution and mapping validation
# Every person-identifier column in every source, with its name column when one exists.
ID_COLUMNS = [
    ("HR4U", "hr4u_employees", "manager_id", "manager_name"),
    ("HR4U", "hr4u_employee_goals", "employee_id", None), ("HR4U", "hr4u_employee_goals", "manager_id", None),
    ("HR4U", "hr4u_employee_mobility", "employee_id", None),
    ("HR4U", "hr4u_performance_reviews", "employee_id", None), ("HR4U", "hr4u_performance_reviews", "reviewer_id", None),
    ("Jira", "jira_issues", "assignee_id", "assignee_name"), ("Jira", "jira_issues", "reporter_id", None),
    ("Jira", "jira_worklogs", "employee_id", "employee_name"),
    ("ServiceNow", "servicenow_incidents", "employee_id", "employee_name"),
    ("ServiceNow", "servicenow_incidents", "assigned_to_id", "assigned_to_name"),
    ("ServiceNow", "servicenow_requests", "employee_id", None), ("ServiceNow", "servicenow_requests", "assigned_to_id", None),
    ("ServiceNow", "servicenow_tasks", "employee_id", None), ("ServiceNow", "servicenow_tasks", "assigned_to_id", None),
    ("LMS", "lms_learning_activity", "employee_id", None), ("LMS", "lms_certifications", "employee_id", None),
    ("HR4U", "hr4u_employee_skills", "employee_id", None), ("HR4U", "hr4u_manager_access", "manager_employee_id", None),
]
started = datetime.now()
parts = [f"""SELECT '{sys}' AS source_system, '{ent}' AS source_entity, '{col}' AS source_column,
  {col} AS source_identifier, {name or 'CAST(NULL AS STRING)'} AS source_name, count(*) AS record_count
FROM {fq(SILVER_PREFIX + ent)} WHERE {col} IS NOT NULL AND {col} <> '*' GROUP BY ALL""" for sys, ent, col, name in ID_COLUMNS]
IDMAP_TABLE = fq(SILVER_PREFIX + "employee_identity_map")
spark.sql(f"""CREATE OR REPLACE TABLE {IDMAP_TABLE}
COMMENT 'Silver employee identity map: every person identifier found in HR4U, Jira, ServiceNow and LMS, resolved to the HR4U employee_id (exact ID match), with a check that the names agree.'
AS
WITH ids AS ({' UNION ALL '.join(parts)})
SELECT i.source_system, i.source_entity, i.source_column, i.source_identifier, i.source_name,
  h.employee_id, h.employee_name AS hr_employee_name,
  'EXACT_EMPLOYEE_ID' AS match_method,
  CASE WHEN h.employee_id IS NULL THEN 'UNMATCHED' ELSE 'MATCHED' END AS match_status,
  CASE WHEN i.source_name IS NULL OR h.employee_id IS NULL THEN NULL ELSE i.source_name = h.employee_name END AS name_matches_hr,
  SUM(i.record_count) AS record_count, current_timestamp() AS resolved_at
FROM ids i LEFT JOIN {fq(SILVER_PREFIX + 'hr4u_employees')} h ON i.source_identifier = h.employee_id
GROUP BY ALL""")
log_audit(RUN_ID, "silver", "employee_identity_map", "SUCCESS", spark.table(IDMAP_TABLE).count(), started)
display(spark.sql(f"""SELECT source_system, source_entity, source_column, count(*) AS distinct_ids,
  sum(IF(match_status = 'MATCHED', 1, 0)) AS matched_ids, sum(record_count) AS records,
  sum(IF(match_status = 'MATCHED', record_count, 0)) AS matched_records,
  sum(IF(name_matches_hr = false, 1, 0)) AS name_mismatches
FROM {IDMAP_TABLE} GROUP BY ALL ORDER BY 1, 2, 3"""))

# COMMAND ----------

# DBTITLE 1,Data quality checks
def S(name): return fq(SILVER_PREFIX + name)
# (check_name, table, severity, SQL returning failed_rows and total_rows)
CHECKS = []
for src, cfg in SOURCES.items():
    k = ", ".join(cfg["pk"])
    CHECKS.append((f"{src}: primary key not null", src, "CRITICAL",
        f"SELECT sum(IF({' OR '.join(c + ' IS NULL' for c in cfg['pk'])}, 1, 0)), count(*) FROM {S(src)}"))
    CHECKS.append((f"{src}: primary key unique", src, "CRITICAL",
        f"SELECT count(*) - count(DISTINCT {k}), count(*) FROM {S(src)}"))
CHECKS += [
    ("identity: unmatched person identifiers", "employee_identity_map", "WARN",
     f"SELECT sum(IF(match_status = 'UNMATCHED', record_count, 0)), sum(record_count) FROM {IDMAP_TABLE}"),
    ("identity: source name differs from HR name", "employee_identity_map", "WARN",
     f"SELECT sum(IF(name_matches_hr = false, record_count, 0)), sum(record_count) FROM {IDMAP_TABLE}"),
    ("scd2: one current version per employee", "hr4u_employees_scd2", "CRITICAL",
     f"SELECT count(*) - count(DISTINCT employee_id), count(*) FROM {SCD2_TABLE} WHERE is_current"),
    ("jira: created_date parsed", "jira_issues", "CRITICAL", f"SELECT sum(IF(created_date IS NULL, 1, 0)), count(*) FROM {S('jira_issues')}"),
    ("jira: resolved_date not before created_date", "jira_issues", "WARN", f"SELECT sum(IF(resolved_date < created_date, 1, 0)), count(*) FROM {S('jira_issues')}"),
    ("jira: Done issues have resolved_date", "jira_issues", "WARN", f"SELECT sum(IF(status_category = 'Done' AND resolved_date IS NULL, 1, 0)), count(*) FROM {S('jira_issues')}"),
    ("jira: issue sprint exists", "jira_issues", "WARN", f"SELECT sum(IF(s.sprint_id IS NULL AND i.sprint_id IS NOT NULL, 1, 0)), count(*) FROM {S('jira_issues')} i LEFT JOIN {S('jira_sprints')} s ON i.sprint_id = s.sprint_id"),
    ("jira: worklog issue exists", "jira_worklogs", "WARN", f"SELECT sum(IF(i.issue_id IS NULL, 1, 0)), count(*) FROM {S('jira_worklogs')} w LEFT JOIN {S('jira_issues')} i ON w.issue_id = i.issue_id"),
    ("jira: worklog hours between 0 and 24", "jira_worklogs", "WARN", f"SELECT sum(IF(time_spent_hours <= 0 OR time_spent_hours > 24 OR time_spent_hours IS NULL, 1, 0)), count(*) FROM {S('jira_worklogs')}"),
    ("servicenow: opened_date parsed", "servicenow_incidents", "CRITICAL", f"SELECT sum(IF(opened_date IS NULL, 1, 0)), count(*) FROM {S('servicenow_incidents')}"),
    ("servicenow: resolved not before opened", "servicenow_incidents", "WARN", f"SELECT sum(IF(resolved_date < opened_date, 1, 0)), count(*) FROM {S('servicenow_incidents')}"),
    ("servicenow: task parent request exists", "servicenow_tasks", "WARN", f"SELECT sum(IF(r.request_id IS NULL, 1, 0)), count(*) FROM {S('servicenow_tasks')} t LEFT JOIN {S('servicenow_requests')} r ON t.parent_request_id = r.request_id"),
    ("lms: completed activity has completion_date", "lms_learning_activity", "WARN", f"SELECT sum(IF(learning_status = 'Completed' AND completion_date IS NULL, 1, 0)), count(*) FROM {S('lms_learning_activity')}"),
    ("lms: learning course exists", "lms_learning_activity", "WARN", f"SELECT sum(IF(c.course_id IS NULL, 1, 0)), count(*) FROM {S('lms_learning_activity')} a LEFT JOIN {S('lms_courses')} c ON a.course_id = c.course_id"),
    ("lms: certification expiry after issue", "lms_certifications", "WARN", f"SELECT sum(IF(expiry_date < issue_date, 1, 0)), count(*) FROM {S('lms_certifications')}"),
    ("hr: manager exists in HR", "hr4u_employees", "WARN", f"SELECT sum(IF(m.employee_id IS NULL AND e.manager_id IS NOT NULL, 1, 0)), count(*) FROM {S('hr4u_employees')} e LEFT JOIN {S('hr4u_employees')} m ON e.manager_id = m.employee_id"),
]

dq_rows = []
for name, table, severity, sql in CHECKS:
    failed, total = spark.sql(sql).first()
    failed, total = int(failed or 0), int(total or 0)
    dq_rows.append((RUN_ID, table, name, severity, failed, total, "PASS" if failed == 0 else "FAIL", datetime.now()))
dq_df = spark.createDataFrame(dq_rows, "run_id STRING, table_name STRING, check_name STRING, severity STRING, failed_rows BIGINT, total_rows BIGINT, status STRING, checked_at TIMESTAMP")
dq_df.write.mode("append").saveAsTable(DQ_TABLE)
spark.sql(f"COMMENT ON TABLE {DQ_TABLE} IS 'PulseForge Silver data quality results: one row per check per run.'")
display(dq_df.orderBy(F.col("status").desc(), "severity", "check_name"))
critical = [r for r in dq_rows if r[3] == "CRITICAL" and r[6] == "FAIL"]
log_audit(RUN_ID, "silver", "data_quality", "FAILED" if critical else "SUCCESS", len(dq_rows), started,
          f"{sum(r[6] == 'FAIL' for r in dq_rows)} failed checks, {len(critical)} critical")
if critical:
    raise RuntimeError(f"Critical data quality failures: {[r[2] for r in critical]}")