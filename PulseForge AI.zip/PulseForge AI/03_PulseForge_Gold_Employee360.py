# Databricks notebook source
# DBTITLE 1,Gold layer overview
# MAGIC %md
# MAGIC # PulseForge AI - Gold Employee 360 model
# MAGIC Builds business-ready tables in `team_1.gold` from `team_1.silver` only. The first seven use the **same columns** as the legacy `team_1.default.gold_*` tables.
# MAGIC
# MAGIC | Table | Grain | Matches existing |
# MAGIC | --- | --- | --- |
# MAGIC | `gold.employee_360` | employee, as of reporting_date | `gold_employee_360` |
# MAGIC | `gold.employee_career` | mobility record | `gold_employee_career` |
# MAGIC | `gold.employee_learning` | employee x reporting_period | `gold_employee_learning` |
# MAGIC | `gold.employee_operations` | employee x reporting_period | `gold_employee_operations` |
# MAGIC | `gold.employee_performance` | performance review | `gold_employee_performance` |
# MAGIC | `gold.employee_workload` | employee x project x sprint | `gold_employee_workload` |
# MAGIC | `gold.manager_team_summary` | manager x reporting_period | `gold_manager_team_summary` |
# MAGIC | `gold.employee_activity` | one activity record (Jira, ServiceNow, LMS) | new |
# MAGIC | `gold.employee_skills` | employee x skill x evidence source | new |
# MAGIC | `gold.employee_90_180_day_summary` | employee x LAST_90_DAYS / LAST_180_DAYS | new (AI-ready facts) |
# MAGIC | `gold.employee_skill_gaps` | employee x requirement (current / target role) x skill | new |
# MAGIC | `gold.data_freshness` | source entity | new (pipeline freshness) |
# MAGIC
# MAGIC **Periods**: `LAST_30_DAYS`, `LAST_90_DAYS`, `LAST_180_DAYS`, `LAST_365_DAYS`, ending on `current_date()` (inclusive).
# MAGIC **Rules**: completed Jira = `status_category = 'Done'`, dated by `resolved_date`. Issue-level and worklog-level metrics are aggregated separately and then joined, so story points are never duplicated. ServiceNow contribution = the **assignee** (`assigned_to_id`). `Blocked` Jira status, worklog start times, skills, role requirements and manager access come from synthetic batch 01 (`_is_synthetic` in Silver).

# COMMAND ----------

# DBTITLE 1,Load shared config
# MAGIC %run ./00_PulseForge_Config

# COMMAND ----------

# DBTITLE 1,Set schema and reporting periods
# MAGIC %sql
# MAGIC USE CATALOG team_1;
# MAGIC USE SCHEMA gold;
# MAGIC
# MAGIC CREATE OR REPLACE TEMPORARY VIEW reporting_periods AS
# MAGIC SELECT reporting_period, days, date_sub(current_date(), days - 1) AS period_start, current_date() AS period_end
# MAGIC FROM VALUES ('LAST_30_DAYS', 30), ('LAST_90_DAYS', 90), ('LAST_180_DAYS', 180), ('LAST_365_DAYS', 365) AS p(reporting_period, days);

# COMMAND ----------

# DBTITLE 1,gold employee 360
# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE gold.employee_360
# MAGIC COMMENT 'Complete 360-degree employee profile combining HR4U, Jira, ServiceNow and LMS. Grain: one row per employee per reporting_date (lifetime metrics as of that date). Same columns as gold_employee_360.'
# MAGIC AS
# MAGIC WITH jira AS (
# MAGIC   SELECT assignee_id AS employee_id, count(*) AS total_jira_issues,
# MAGIC          sum(IF(status_category = 'Done', 1, 0)) AS completed_issues,
# MAGIC          sum(IF(status_category <> 'Done', 1, 0)) AS open_issues
# MAGIC   FROM silver.jira_issues GROUP BY assignee_id),
# MAGIC wl AS (SELECT employee_id, sum(time_spent_hours) AS total_working_hours FROM silver.jira_worklogs GROUP BY employee_id),
# MAGIC inc AS (
# MAGIC   SELECT assigned_to_id AS employee_id, count(*) AS total_incidents,
# MAGIC          sum(IF(is_resolved, 1, 0)) AS resolved_incidents, sum(IF(is_open, 1, 0)) AS open_incidents
# MAGIC   FROM silver.servicenow_incidents WHERE assigned_to_id IS NOT NULL GROUP BY assigned_to_id),
# MAGIC rev AS (
# MAGIC   SELECT employee_id, overall_rating AS latest_performance_rating FROM (
# MAGIC     SELECT employee_id, overall_rating, row_number() OVER (PARTITION BY employee_id ORDER BY review_date DESC) AS rn
# MAGIC     FROM silver.hr4u_performance_reviews WHERE review_status = 'Completed') WHERE rn = 1),
# MAGIC goals AS (SELECT employee_id, avg(completion_percentage) AS goal_completion_percentage FROM silver.hr4u_employee_goals GROUP BY employee_id),
# MAGIC lms AS (
# MAGIC   SELECT employee_id, count(*) AS courses_enrolled, sum(IF(learning_status = 'Completed', 1, 0)) AS courses_completed,
# MAGIC          sum(learning_hours) AS total_learning_hours
# MAGIC   FROM silver.lms_learning_activity GROUP BY employee_id),
# MAGIC cert AS (
# MAGIC   SELECT employee_id, count(*) AS certifications_count,
# MAGIC          sum(IF(certification_status = 'Active' AND (expiry_date IS NULL OR expiry_date >= current_date()), 1, 0)) AS active_certifications_count
# MAGIC   FROM silver.lms_certifications GROUP BY employee_id)
# MAGIC SELECT e.employee_id, e.employee_name, e.email, e.department_name, e.business_unit, e.job_title, e.job_level,
# MAGIC   e.manager_id, e.manager_name, e.location, e.country, e.joining_date, e.employment_status, e.experience_years,
# MAGIC   CAST(coalesce(j.total_jira_issues, 0) AS INT) AS total_jira_issues,
# MAGIC   CAST(coalesce(j.completed_issues, 0) AS INT) AS completed_issues,
# MAGIC   CAST(coalesce(j.open_issues, 0) AS INT) AS open_issues,
# MAGIC   CAST(coalesce(w.total_working_hours, 0) AS DECIMAL(10,2)) AS total_working_hours,
# MAGIC   CAST(coalesce(i.total_incidents, 0) AS INT) AS total_incidents,
# MAGIC   CAST(coalesce(i.resolved_incidents, 0) AS INT) AS resolved_incidents,
# MAGIC   CAST(coalesce(i.open_incidents, 0) AS INT) AS open_incidents,
# MAGIC   CAST(r.latest_performance_rating AS DECIMAL(4,2)) AS latest_performance_rating,
# MAGIC   CAST(g.goal_completion_percentage AS DECIMAL(5,2)) AS goal_completion_percentage,
# MAGIC   CAST(coalesce(l.courses_enrolled, 0) AS INT) AS courses_enrolled,
# MAGIC   CAST(coalesce(l.courses_completed, 0) AS INT) AS courses_completed,
# MAGIC   CAST(coalesce(l.total_learning_hours, 0) AS DECIMAL(10,2)) AS total_learning_hours,
# MAGIC   CAST(coalesce(c.certifications_count, 0) AS INT) AS certifications_count,
# MAGIC   CAST(coalesce(c.active_certifications_count, 0) AS INT) AS active_certifications_count,
# MAGIC   current_date() AS reporting_date,
# MAGIC   e.last_updated_date
# MAGIC FROM silver.hr4u_employees e
# MAGIC LEFT JOIN jira j ON j.employee_id = e.employee_id
# MAGIC LEFT JOIN wl w ON w.employee_id = e.employee_id
# MAGIC LEFT JOIN inc i ON i.employee_id = e.employee_id
# MAGIC LEFT JOIN rev r ON r.employee_id = e.employee_id
# MAGIC LEFT JOIN goals g ON g.employee_id = e.employee_id
# MAGIC LEFT JOIN lms l ON l.employee_id = e.employee_id
# MAGIC LEFT JOIN cert c ON c.employee_id = e.employee_id;

# COMMAND ----------

# DBTITLE 1,gold employee career
# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE gold.employee_career
# MAGIC COMMENT 'Employee skills, career interests, internal mobility and development opportunities. Grain: one row per employee per mobility record. Source: hr4u_employee_mobility, lms_certifications, hr4u_employees. Same columns as gold_employee_career.'
# MAGIC AS
# MAGIC WITH certs AS (
# MAGIC   SELECT employee_id, count(*) AS total_certifications, array_sort(collect_set(skill_category)) AS skill_categories
# MAGIC   FROM silver.lms_certifications GROUP BY employee_id)
# MAGIC SELECT m.mobility_id, m.employee_id, e.employee_name, e.department_name, m.current_role, m.previous_role,
# MAGIC   m.current_department, m.previous_department, m.mobility_type, m.effective_date, m.career_interest, m.target_role,
# MAGIC   m.mobility_status, CAST(coalesce(c.total_certifications, 0) AS INT) AS total_certifications,
# MAGIC   coalesce(c.skill_categories, CAST(array() AS ARRAY<STRING>)) AS skill_categories,
# MAGIC   e.manager_id AS reporting_manager_id, current_date() AS reporting_date
# MAGIC FROM silver.hr4u_employee_mobility m
# MAGIC JOIN silver.hr4u_employees e ON e.employee_id = m.employee_id
# MAGIC LEFT JOIN certs c ON c.employee_id = m.employee_id;

# COMMAND ----------

# DBTITLE 1,gold employee learning
# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE gold.employee_learning
# MAGIC COMMENT 'Learning progress, course completion, training hours and certifications. Grain: one row per employee per reporting_period. Window metrics use enrollment/completion/issue dates inside the period; in-progress, pending, active, expired and pending certification counts are as of reporting_date. Same columns as gold_employee_learning.'
# MAGIC AS
# MAGIC WITH la AS (
# MAGIC   SELECT a.employee_id, p.reporting_period,
# MAGIC     count(CASE WHEN a.enrollment_date BETWEEN p.period_start AND p.period_end THEN 1 END) AS total_courses_enrolled,
# MAGIC     count(CASE WHEN a.learning_status = 'In Progress' AND a.enrollment_date <= p.period_end THEN 1 END) AS courses_in_progress,
# MAGIC     count(CASE WHEN a.completion_date BETWEEN p.period_start AND p.period_end THEN 1 END) AS courses_completed,
# MAGIC     count(CASE WHEN a.learning_status = 'Enrolled' AND a.enrollment_date <= p.period_end THEN 1 END) AS courses_pending,
# MAGIC     sum(CASE WHEN a.completion_date BETWEEN p.period_start AND p.period_end THEN a.learning_hours ELSE 0 END) AS total_learning_hours,
# MAGIC     avg(CASE WHEN a.enrollment_date <= p.period_end AND coalesce(a.completion_date, a.last_activity_date, a.enrollment_date) >= p.period_start THEN a.progress_percentage END) AS average_course_progress,
# MAGIC     avg(CASE WHEN a.completion_date BETWEEN p.period_start AND p.period_end THEN a.assessment_score END) AS average_assessment_score,
# MAGIC     count(CASE WHEN a.completion_date BETWEEN p.period_start AND p.period_end AND a.pass_status = 'Passed' THEN 1 END) AS courses_passed,
# MAGIC     count(CASE WHEN a.completion_date BETWEEN p.period_start AND p.period_end AND a.pass_status = 'Failed' THEN 1 END) AS courses_failed,
# MAGIC     max(CASE WHEN a.completion_date <= p.period_end THEN a.completion_date END) AS latest_course_completion_date
# MAGIC   FROM silver.lms_learning_activity a CROSS JOIN reporting_periods p GROUP BY a.employee_id, p.reporting_period),
# MAGIC ct AS (
# MAGIC   SELECT c.employee_id, p.reporting_period,
# MAGIC     count(CASE WHEN c.issue_date BETWEEN p.period_start AND p.period_end THEN 1 END) AS total_certifications,
# MAGIC     count(CASE WHEN c.certification_status = 'Active' AND (c.expiry_date IS NULL OR c.expiry_date >= current_date()) THEN 1 END) AS active_certifications,
# MAGIC     count(CASE WHEN c.certification_status = 'Expired' OR (c.certification_status = 'Active' AND c.expiry_date < current_date()) THEN 1 END) AS expired_certifications,
# MAGIC     count(CASE WHEN c.certification_status = 'In Progress' THEN 1 END) AS pending_certifications,
# MAGIC     max(CASE WHEN c.issue_date <= p.period_end THEN c.issue_date END) AS latest_certification_date
# MAGIC   FROM silver.lms_certifications c CROSS JOIN reporting_periods p GROUP BY c.employee_id, p.reporting_period)
# MAGIC SELECT e.employee_id, e.employee_name, e.department_name, e.manager_id,
# MAGIC   CAST(coalesce(la.total_courses_enrolled, 0) AS INT) AS total_courses_enrolled,
# MAGIC   CAST(coalesce(la.courses_in_progress, 0) AS INT) AS courses_in_progress,
# MAGIC   CAST(coalesce(la.courses_completed, 0) AS INT) AS courses_completed,
# MAGIC   CAST(coalesce(la.courses_pending, 0) AS INT) AS courses_pending,
# MAGIC   CAST(coalesce(la.total_learning_hours, 0) AS DECIMAL(10,2)) AS total_learning_hours,
# MAGIC   CAST(la.average_course_progress AS DECIMAL(5,2)) AS average_course_progress,
# MAGIC   CAST(la.average_assessment_score AS DECIMAL(5,2)) AS average_assessment_score,
# MAGIC   CAST(coalesce(la.courses_passed, 0) AS INT) AS courses_passed,
# MAGIC   CAST(coalesce(la.courses_failed, 0) AS INT) AS courses_failed,
# MAGIC   CAST(coalesce(ct.total_certifications, 0) AS INT) AS total_certifications,
# MAGIC   CAST(coalesce(ct.active_certifications, 0) AS INT) AS active_certifications,
# MAGIC   CAST(coalesce(ct.expired_certifications, 0) AS INT) AS expired_certifications,
# MAGIC   CAST(coalesce(ct.pending_certifications, 0) AS INT) AS pending_certifications,
# MAGIC   la.latest_course_completion_date, ct.latest_certification_date,
# MAGIC   p.reporting_period, current_date() AS reporting_date
# MAGIC FROM silver.hr4u_employees e CROSS JOIN reporting_periods p
# MAGIC LEFT JOIN la ON la.employee_id = e.employee_id AND la.reporting_period = p.reporting_period
# MAGIC LEFT JOIN ct ON ct.employee_id = e.employee_id AND ct.reporting_period = p.reporting_period;

# COMMAND ----------

# DBTITLE 1,gold employee operations
# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE gold.employee_operations
# MAGIC COMMENT 'ServiceNow incidents, service requests, operational issues and SLA performance for the employee as ASSIGNEE. Grain: one row per employee per reporting_period (incidents by opened_date, requests by request_date inside the period). Same columns as gold_employee_operations.'
# MAGIC AS
# MAGIC WITH inc AS (
# MAGIC   SELECT i.assigned_to_id AS employee_id, p.reporting_period,
# MAGIC     count(*) AS total_incidents,
# MAGIC     sum(IF(i.is_open, 1, 0)) AS open_incidents,
# MAGIC     sum(IF(i.state = 'Resolved', 1, 0)) AS resolved_incidents,
# MAGIC     sum(IF(i.state = 'Closed', 1, 0)) AS closed_incidents,
# MAGIC     sum(IF(i.priority = 'Critical', 1, 0)) AS critical_incidents,
# MAGIC     sum(IF(i.priority = 'High', 1, 0)) AS high_priority_incidents,
# MAGIC     sum(IF(i.sla_status = 'Breached', 1, 0)) AS breached_sla_count,
# MAGIC     sum(IF(i.sla_status = 'Met', 1, 0)) AS met_sla_count,
# MAGIC     avg(i.resolution_time_hours) AS average_resolution_hours,
# MAGIC     sum(IF(i.reopen_count > 0, 1, 0)) AS reopened_incidents,
# MAGIC     avg(i.satisfaction_score) AS average_satisfaction_score
# MAGIC   FROM silver.servicenow_incidents i JOIN reporting_periods p ON to_date(i.opened_date) BETWEEN p.period_start AND p.period_end
# MAGIC   WHERE i.assigned_to_id IS NOT NULL GROUP BY ALL),
# MAGIC req AS (
# MAGIC   SELECT r.assigned_to_id AS employee_id, p.reporting_period,
# MAGIC     count(*) AS total_requests, sum(IF(r.is_open, 1, 0)) AS pending_requests,
# MAGIC     sum(IF(r.is_completed, 1, 0)) AS completed_requests,
# MAGIC     sum(IF(r.request_status = 'Closed Rejected', 1, 0)) AS rejected_requests,
# MAGIC     avg(r.fulfillment_time_hours) AS average_fulfillment_hours
# MAGIC   FROM silver.servicenow_requests r JOIN reporting_periods p ON to_date(r.request_date) BETWEEN p.period_start AND p.period_end
# MAGIC   WHERE r.assigned_to_id IS NOT NULL GROUP BY ALL)
# MAGIC SELECT e.employee_id, e.employee_name, e.department_name, e.manager_id,
# MAGIC   CAST(coalesce(i.total_incidents, 0) AS INT) AS total_incidents,
# MAGIC   CAST(coalesce(i.open_incidents, 0) AS INT) AS open_incidents,
# MAGIC   CAST(coalesce(i.resolved_incidents, 0) AS INT) AS resolved_incidents,
# MAGIC   CAST(coalesce(i.closed_incidents, 0) AS INT) AS closed_incidents,
# MAGIC   CAST(coalesce(i.critical_incidents, 0) AS INT) AS critical_incidents,
# MAGIC   CAST(coalesce(i.high_priority_incidents, 0) AS INT) AS high_priority_incidents,
# MAGIC   CAST(coalesce(i.breached_sla_count, 0) AS INT) AS breached_sla_count,
# MAGIC   CAST(coalesce(i.met_sla_count, 0) AS INT) AS met_sla_count,
# MAGIC   CAST(i.average_resolution_hours AS DECIMAL(10,2)) AS average_resolution_hours,
# MAGIC   CAST(coalesce(i.reopened_incidents, 0) AS INT) AS reopened_incidents,
# MAGIC   CAST(coalesce(r.total_requests, 0) AS INT) AS total_requests,
# MAGIC   CAST(coalesce(r.pending_requests, 0) AS INT) AS pending_requests,
# MAGIC   CAST(coalesce(r.completed_requests, 0) AS INT) AS completed_requests,
# MAGIC   CAST(coalesce(r.rejected_requests, 0) AS INT) AS rejected_requests,
# MAGIC   CAST(r.average_fulfillment_hours AS DECIMAL(10,2)) AS average_fulfillment_hours,
# MAGIC   CAST(i.average_satisfaction_score AS DECIMAL(4,2)) AS average_satisfaction_score,
# MAGIC   p.reporting_period, current_date() AS reporting_date
# MAGIC FROM silver.hr4u_employees e CROSS JOIN reporting_periods p
# MAGIC LEFT JOIN inc i ON i.employee_id = e.employee_id AND i.reporting_period = p.reporting_period
# MAGIC LEFT JOIN req r ON r.employee_id = e.employee_id AND r.reporting_period = p.reporting_period;

# COMMAND ----------

# DBTITLE 1,gold employee performance
# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE gold.employee_performance
# MAGIC COMMENT 'SENSITIVE HR DATA. Performance reviews with goals for the same half-year (goal start_date half-year = review_period). Grain: one row per employee per review. For authorised HR/manager use only; never used by AI summaries. Same columns as gold_employee_performance.'
# MAGIC AS
# MAGIC WITH g AS (
# MAGIC   SELECT employee_id, goal_period, count(*) AS total_goals,
# MAGIC          sum(IF(goal_status = 'Completed', 1, 0)) AS completed_goals,
# MAGIC          avg(completion_percentage) AS goal_completion_percentage
# MAGIC   FROM silver.hr4u_employee_goals GROUP BY employee_id, goal_period)
# MAGIC SELECT r.review_id, r.employee_id, e.employee_name, e.manager_id, e.department_name, r.review_period, r.review_date,
# MAGIC   r.overall_rating, r.goal_achievement_score, r.collaboration_score, r.delivery_score,
# MAGIC   r.strengths, r.improvement_areas, r.manager_feedback, r.review_status,
# MAGIC   CAST(coalesce(g.total_goals, 0) AS INT) AS total_goals,
# MAGIC   CAST(coalesce(g.completed_goals, 0) AS INT) AS completed_goals,
# MAGIC   CAST(g.goal_completion_percentage AS DECIMAL(5,2)) AS goal_completion_percentage,
# MAGIC   current_date() AS reporting_date
# MAGIC FROM silver.hr4u_performance_reviews r
# MAGIC JOIN silver.hr4u_employees e ON e.employee_id = r.employee_id
# MAGIC LEFT JOIN g ON g.employee_id = r.employee_id AND g.goal_period = r.review_period;

# COMMAND ----------

# DBTITLE 1,gold employee workload
# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE gold.employee_workload
# MAGIC COMMENT 'Employee workload, Jira activity, sprint commitments and delivery. Grain: one row per employee per project per sprint; reporting_period = month the sprint ends (yyyy-MM), reporting_date = sprint end date. Issue metrics use the assignee; working hours use worklog authors; both are aggregated separately before joining. Task counts are workload context, not productivity. Same columns as gold_employee_workload.'
# MAGIC AS
# MAGIC WITH iss AS (
# MAGIC   SELECT assignee_id AS employee_id, project_id, project_name, sprint_id,
# MAGIC     count(*) AS total_issues,
# MAGIC     sum(IF(status_category = 'Done', 1, 0)) AS completed_issues,
# MAGIC     sum(IF(status_category <> 'Done', 1, 0)) AS open_issues,
# MAGIC     sum(IF(is_blocked, 1, 0)) AS blocked_issues,
# MAGIC     sum(IF(priority IN ('High', 'Highest', 'Critical'), 1, 0)) AS high_priority_issues,
# MAGIC     sum(story_points) AS total_story_points,
# MAGIC     sum(IF(status_category = 'Done', story_points, 0)) AS completed_story_points,
# MAGIC     sum(IF(status_category <> 'Done' AND due_date < current_date(), 1, 0)) AS overdue_issues,
# MAGIC     max(coalesce(resolved_date, updated_date, created_date)) AS last_issue_activity
# MAGIC   FROM silver.jira_issues GROUP BY ALL),
# MAGIC wl AS (
# MAGIC   SELECT w.employee_id, i.project_id, i.project_name, i.sprint_id,
# MAGIC     sum(w.time_spent_hours) AS total_working_hours, count(DISTINCT w.issue_id) AS worked_issues, max(w.work_date) AS last_worklog_date
# MAGIC   FROM silver.jira_worklogs w JOIN silver.jira_issues i ON i.issue_id = w.issue_id GROUP BY ALL),
# MAGIC k AS (
# MAGIC   SELECT employee_id, project_id, project_name, sprint_id FROM iss
# MAGIC   UNION SELECT employee_id, project_id, project_name, sprint_id FROM wl)
# MAGIC SELECT k.employee_id, e.employee_name, e.department_name, e.manager_id, k.project_id, k.project_name, k.sprint_id,
# MAGIC   CAST(coalesce(iss.total_issues, 0) AS INT) AS total_issues,
# MAGIC   CAST(coalesce(iss.completed_issues, 0) AS INT) AS completed_issues,
# MAGIC   CAST(coalesce(iss.open_issues, 0) AS INT) AS open_issues,
# MAGIC   CAST(coalesce(iss.blocked_issues, 0) AS INT) AS blocked_issues,
# MAGIC   CAST(coalesce(iss.high_priority_issues, 0) AS INT) AS high_priority_issues,
# MAGIC   CAST(coalesce(iss.total_story_points, 0) AS DECIMAL(10,2)) AS total_story_points,
# MAGIC   CAST(coalesce(iss.completed_story_points, 0) AS DECIMAL(10,2)) AS completed_story_points,
# MAGIC   CAST(CASE WHEN iss.total_story_points > 0 THEN 100 * iss.completed_story_points / iss.total_story_points END AS DECIMAL(5,2)) AS completion_percentage,
# MAGIC   CAST(coalesce(wl.total_working_hours, 0) AS DECIMAL(10,2)) AS total_working_hours,
# MAGIC   CAST(wl.total_working_hours / nullif(wl.worked_issues, 0) AS DECIMAL(10,2)) AS average_hours_per_issue,
# MAGIC   CAST(coalesce(iss.overdue_issues, 0) AS INT) AS overdue_issues,
# MAGIC   greatest(iss.last_issue_activity, wl.last_worklog_date) AS last_activity_date,
# MAGIC   date_format(s.end_date, 'yyyy-MM') AS reporting_period,
# MAGIC   s.end_date AS reporting_date
# MAGIC FROM k
# MAGIC JOIN silver.hr4u_employees e ON e.employee_id = k.employee_id
# MAGIC LEFT JOIN iss ON iss.employee_id = k.employee_id AND iss.project_id = k.project_id AND iss.sprint_id <=> k.sprint_id
# MAGIC LEFT JOIN wl ON wl.employee_id = k.employee_id AND wl.project_id = k.project_id AND wl.sprint_id <=> k.sprint_id
# MAGIC LEFT JOIN silver.jira_sprints s ON s.sprint_id = k.sprint_id;

# COMMAND ----------

# DBTITLE 1,gold manager team summary
# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE gold.manager_team_summary
# MAGIC COMMENT 'Team-level insights for managers. Grain: one row per manager per reporting_period, aggregated over direct reports (hr4u manager_id). Issues = assigned issues active in the period; completed = resolved in the period; incidents = assigned incidents opened in the period. Same columns as gold_manager_team_summary.'
# MAGIC AS
# MAGIC WITH team AS (SELECT manager_id, employee_id, employment_status FROM silver.hr4u_employees WHERE manager_id IS NOT NULL),
# MAGIC iss AS (
# MAGIC   SELECT i.assignee_id AS employee_id, p.reporting_period,
# MAGIC     sum(IF(i.created_date <= p.period_end AND (i.resolved_date IS NULL OR i.resolved_date >= p.period_start), 1, 0)) AS total_issues,
# MAGIC     sum(IF(i.resolved_date BETWEEN p.period_start AND p.period_end, 1, 0)) AS completed_issues,
# MAGIC     sum(IF(i.status_category <> 'Done', 1, 0)) AS open_issues
# MAGIC   FROM silver.jira_issues i CROSS JOIN reporting_periods p GROUP BY ALL),
# MAGIC wl AS (
# MAGIC   SELECT w.employee_id, p.reporting_period, sum(w.time_spent_hours) AS hours
# MAGIC   FROM silver.jira_worklogs w JOIN reporting_periods p ON w.work_date BETWEEN p.period_start AND p.period_end GROUP BY ALL),
# MAGIC inc AS (
# MAGIC   SELECT i.assigned_to_id AS employee_id, p.reporting_period, count(*) AS incidents,
# MAGIC     sum(IF(i.sla_status = 'Breached', 1, 0)) AS breached
# MAGIC   FROM silver.servicenow_incidents i JOIN reporting_periods p ON to_date(i.opened_date) BETWEEN p.period_start AND p.period_end
# MAGIC   WHERE i.assigned_to_id IS NOT NULL GROUP BY ALL),
# MAGIC rating AS (
# MAGIC   SELECT employee_id, overall_rating FROM (
# MAGIC     SELECT employee_id, overall_rating, row_number() OVER (PARTITION BY employee_id ORDER BY review_date DESC) AS rn
# MAGIC     FROM silver.hr4u_performance_reviews WHERE review_status = 'Completed') WHERE rn = 1),
# MAGIC goals AS (SELECT employee_id, avg(completion_percentage) AS goal_pct FROM silver.hr4u_employee_goals GROUP BY employee_id),
# MAGIC la AS (
# MAGIC   SELECT a.employee_id, p.reporting_period,
# MAGIC     sum(IF(a.completion_date BETWEEN p.period_start AND p.period_end, 1, 0)) AS courses_completed,
# MAGIC     sum(IF(a.completion_date BETWEEN p.period_start AND p.period_end, a.learning_hours, 0)) AS learning_hours,
# MAGIC     max(IF(coalesce(a.last_activity_date, a.enrollment_date) BETWEEN p.period_start AND p.period_end, 1, 0)) AS has_recent_learning
# MAGIC   FROM silver.lms_learning_activity a CROSS JOIN reporting_periods p GROUP BY ALL),
# MAGIC ct AS (
# MAGIC   SELECT c.employee_id, p.reporting_period, sum(IF(c.issue_date BETWEEN p.period_start AND p.period_end, 1, 0)) AS certs
# MAGIC   FROM silver.lms_certifications c CROSS JOIN reporting_periods p GROUP BY ALL)
# MAGIC SELECT t.manager_id, m.employee_name AS manager_name, m.department_name,
# MAGIC   CAST(count(*) AS INT) AS total_team_members,
# MAGIC   CAST(sum(IF(t.employment_status = 'Active', 1, 0)) AS INT) AS active_employees,
# MAGIC   CAST(sum(IF(t.employment_status = 'On Leave', 1, 0)) AS INT) AS employees_on_leave,
# MAGIC   CAST(sum(coalesce(iss.total_issues, 0)) AS INT) AS total_team_issues,
# MAGIC   CAST(sum(coalesce(iss.completed_issues, 0)) AS INT) AS completed_team_issues,
# MAGIC   CAST(sum(coalesce(iss.open_issues, 0)) AS INT) AS open_team_issues,
# MAGIC   CAST(avg(coalesce(wl.hours, 0)) AS DECIMAL(10,2)) AS average_workload_hours,
# MAGIC   CAST(sum(coalesce(inc.incidents, 0)) AS INT) AS total_team_incidents,
# MAGIC   CAST(sum(coalesce(inc.breached, 0)) AS INT) AS breached_sla_count,
# MAGIC   CAST(avg(rating.overall_rating) AS DECIMAL(4,2)) AS average_team_performance_rating,
# MAGIC   CAST(avg(goals.goal_pct) AS DECIMAL(5,2)) AS average_goal_completion_percentage,
# MAGIC   CAST(sum(coalesce(la.courses_completed, 0)) AS INT) AS total_team_courses_completed,
# MAGIC   CAST(avg(coalesce(la.learning_hours, 0)) AS DECIMAL(10,2)) AS average_learning_hours,
# MAGIC   CAST(sum(coalesce(ct.certs, 0)) AS INT) AS total_team_certifications,
# MAGIC   CAST(sum(IF(coalesce(la.has_recent_learning, 0) = 0, 1, 0)) AS INT) AS employees_with_no_recent_learning,
# MAGIC   p.reporting_period, current_date() AS reporting_date
# MAGIC FROM team t
# MAGIC JOIN silver.hr4u_employees m ON m.employee_id = t.manager_id
# MAGIC CROSS JOIN reporting_periods p
# MAGIC LEFT JOIN iss ON iss.employee_id = t.employee_id AND iss.reporting_period = p.reporting_period
# MAGIC LEFT JOIN wl ON wl.employee_id = t.employee_id AND wl.reporting_period = p.reporting_period
# MAGIC LEFT JOIN inc ON inc.employee_id = t.employee_id AND inc.reporting_period = p.reporting_period
# MAGIC LEFT JOIN rating ON rating.employee_id = t.employee_id
# MAGIC LEFT JOIN goals ON goals.employee_id = t.employee_id
# MAGIC LEFT JOIN la ON la.employee_id = t.employee_id AND la.reporting_period = p.reporting_period
# MAGIC LEFT JOIN ct ON ct.employee_id = t.employee_id AND ct.reporting_period = p.reporting_period
# MAGIC GROUP BY t.manager_id, m.employee_name, m.department_name, p.reporting_period;

# COMMAND ----------

# DBTITLE 1,gold employee activity timeline
# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE gold.employee_activity
# MAGIC COMMENT 'Unified factual timeline of employee activity from Jira (assigned issues, worklogs), ServiceNow (assigned incidents, requests, tasks) and LMS (courses, certifications). Grain: one row per source record per employee. Use for recent events, evidence behind summaries and 1:1 preparation.'
# MAGIC AS
# MAGIC WITH a AS (
# MAGIC   SELECT concat('JIRA-ISSUE-', issue_id) AS activity_id, assignee_id AS employee_id, coalesce(resolved_date, created_date) AS activity_date,
# MAGIC     'Jira' AS activity_source, concat('Jira ', issue_type) AS activity_type, concat(issue_key, ' - ', summary) AS activity_title,
# MAGIC     project_name, sprint_id, status AS activity_status, priority, story_points,
# MAGIC     CAST(NULL AS DECIMAL(10,2)) AS effort_hours, CAST(NULL AS DECIMAL(10,2)) AS elapsed_hours, issue_id AS source_record_id, 'silver.jira_issues' AS source_table
# MAGIC   FROM silver.jira_issues
# MAGIC   UNION ALL
# MAGIC   SELECT concat('JIRA-WORKLOG-', w.worklog_id), w.employee_id, w.work_date, 'Jira', 'Jira Worklog', concat(i.issue_key, ' - ', w.work_description),
# MAGIC     i.project_name, i.sprint_id, 'Logged', i.priority, CAST(NULL AS DECIMAL(10,2)), CAST(w.time_spent_hours AS DECIMAL(10,2)), NULL, w.worklog_id, 'silver.jira_worklogs'
# MAGIC   FROM silver.jira_worklogs w LEFT JOIN silver.jira_issues i ON i.issue_id = w.issue_id
# MAGIC   UNION ALL
# MAGIC   SELECT concat('SN-INCIDENT-', incident_id), assigned_to_id, to_date(coalesce(resolved_date, opened_date)), 'ServiceNow', 'Incident Assigned',
# MAGIC     concat(incident_id, ' - ', short_description), assignment_group, NULL, state, priority, NULL, NULL, resolution_time_hours, incident_id, 'silver.servicenow_incidents'
# MAGIC   FROM silver.servicenow_incidents WHERE assigned_to_id IS NOT NULL
# MAGIC   UNION ALL
# MAGIC   SELECT concat('SN-REQUEST-', request_id), assigned_to_id, to_date(coalesce(completion_date, request_date)), 'ServiceNow', 'Service Request Assigned',
# MAGIC     concat(request_id, ' - ', requested_item), assigned_group, NULL, request_status, NULL, NULL, NULL, fulfillment_time_hours, request_id, 'silver.servicenow_requests'
# MAGIC   FROM silver.servicenow_requests WHERE assigned_to_id IS NOT NULL
# MAGIC   UNION ALL
# MAGIC   SELECT concat('SN-TASK-', task_id), assigned_to_id, to_date(coalesce(completed_date, created_date)), 'ServiceNow', concat('Service Task - ', task_type),
# MAGIC     concat(task_id, ' - ', work_notes), NULL, NULL, task_status, priority, NULL, NULL,
# MAGIC     CAST(round((unix_timestamp(completed_date) - unix_timestamp(created_date)) / 3600.0, 2) AS DECIMAL(10,2)), task_id, 'silver.servicenow_tasks'
# MAGIC   FROM silver.servicenow_tasks WHERE assigned_to_id IS NOT NULL
# MAGIC   UNION ALL
# MAGIC   SELECT concat('LMS-LEARNING-', a.learning_activity_id), a.employee_id, coalesce(a.completion_date, a.last_activity_date, a.enrollment_date), 'LMS',
# MAGIC     concat('Course ', a.learning_status), c.course_name, NULL, NULL, a.learning_status, NULL, NULL, CAST(a.learning_hours AS DECIMAL(10,2)), NULL,
# MAGIC     a.learning_activity_id, 'silver.lms_learning_activity'
# MAGIC   FROM silver.lms_learning_activity a LEFT JOIN silver.lms_courses c ON c.course_id = a.course_id
# MAGIC   UNION ALL
# MAGIC   SELECT concat('LMS-CERT-', certification_id), employee_id, issue_date, 'LMS', 'Certification', certification_name, NULL, NULL,
# MAGIC     certification_status, NULL, NULL, NULL, NULL, certification_id, 'silver.lms_certifications'
# MAGIC   FROM silver.lms_certifications)
# MAGIC SELECT a.activity_id, a.employee_id, e.employee_name, e.manager_id, e.department_name, a.activity_date,
# MAGIC   date_format(a.activity_date, 'yyyy-MM') AS activity_month, a.activity_source, a.activity_type, a.activity_title,
# MAGIC   a.project_name, a.sprint_id, s.sprint_name, a.activity_status, a.priority, a.story_points, a.effort_hours, a.elapsed_hours,
# MAGIC   a.source_record_id, a.source_table, current_date() AS reporting_date
# MAGIC FROM a
# MAGIC JOIN silver.hr4u_employees e ON e.employee_id = a.employee_id
# MAGIC LEFT JOIN silver.jira_sprints s ON s.sprint_id = a.sprint_id;

# COMMAND ----------

# DBTITLE 1,gold employee skills
# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE gold.employee_skills
# MAGIC COMMENT 'Evidence-based skills per employee from LMS certifications (skill_category), LMS courses (skill_name), Jira project experience, HR4U skill profile (synthetic batch01) and HR4U career interests. Grain: employee x skill_name x skill_source. development_opportunity is a rule-based, factual suggestion, not an assessment.'
# MAGIC AS
# MAGIC WITH ev AS (
# MAGIC   SELECT employee_id, skill_category AS skill_name, 'Certification' AS skill_source, certification_name AS evidence_item,
# MAGIC     issue_date AS evidence_date, certification_status AS evidence_status,
# MAGIC     certification_status = 'Active' AND (expiry_date IS NULL OR expiry_date >= current_date()) AS is_active_cert,
# MAGIC     certification_status = 'Expired' OR (certification_status = 'Active' AND expiry_date < current_date()) AS is_expired_cert
# MAGIC   FROM silver.lms_certifications
# MAGIC   UNION ALL
# MAGIC   SELECT a.employee_id, c.skill_name, 'Course', c.course_name, coalesce(a.completion_date, a.last_activity_date, a.enrollment_date), a.learning_status, false, false
# MAGIC   FROM silver.lms_learning_activity a JOIN silver.lms_courses c ON c.course_id = a.course_id
# MAGIC   UNION ALL
# MAGIC   SELECT assignee_id, project_name, 'Project Experience', issue_key, coalesce(resolved_date, created_date), status_category, false, false
# MAGIC   FROM silver.jira_issues
# MAGIC   UNION ALL
# MAGIC   SELECT employee_id, career_interest, 'Career Interest', target_role, effective_date, mobility_status, false, false
# MAGIC   FROM silver.hr4u_employee_mobility WHERE career_interest IS NOT NULL
# MAGIC   UNION ALL
# MAGIC   SELECT employee_id, skill_name, 'HR4U Skill Profile', concat(proficiency_level, ' (', assessment_source, ' assessed)'), last_assessed_date, 'Assessed', false, false
# MAGIC   FROM silver.hr4u_employee_skills),
# MAGIC agg AS (
# MAGIC   SELECT employee_id, skill_name, skill_source,
# MAGIC     count(*) AS evidence_count, array_sort(collect_set(evidence_item)) AS evidence_items, max(evidence_date) AS latest_evidence_date,
# MAGIC     sum(IF(evidence_status IN ('Completed', 'Active', 'Done', 'Assessed'), 1, 0)) AS completed_evidence_count,
# MAGIC     sum(IF(evidence_status IN ('In Progress', 'Enrolled', 'To Do'), 1, 0)) AS in_progress_evidence_count,
# MAGIC     max(is_active_cert) AS has_active_certification, max(is_expired_cert) AS has_expired_certification
# MAGIC   FROM ev GROUP BY ALL)
# MAGIC SELECT a.employee_id, e.employee_name, e.manager_id, e.department_name, e.job_title, a.skill_name, a.skill_source,
# MAGIC   CAST(a.evidence_count AS INT) AS evidence_count, a.evidence_items, a.latest_evidence_date,
# MAGIC   CAST(a.completed_evidence_count AS INT) AS completed_evidence_count,
# MAGIC   CAST(a.in_progress_evidence_count AS INT) AS in_progress_evidence_count,
# MAGIC   a.has_active_certification,
# MAGIC   CASE
# MAGIC     WHEN a.skill_source = 'Certification' AND a.has_expired_certification AND NOT a.has_active_certification THEN 'Renew expired certification'
# MAGIC     WHEN a.skill_source = 'Certification' AND a.in_progress_evidence_count > 0 THEN 'Complete in-progress certification'
# MAGIC     WHEN a.skill_source = 'Course' AND a.in_progress_evidence_count > 0 THEN 'Complete in-progress course'
# MAGIC     WHEN a.skill_source = 'Career Interest' THEN 'Discuss development path toward stated career interest'
# MAGIC     ELSE NULL END AS development_opportunity,
# MAGIC   current_date() AS reporting_date
# MAGIC FROM agg a JOIN silver.hr4u_employees e ON e.employee_id = a.employee_id;

# COMMAND ----------

# DBTITLE 1,gold employee skill gaps
# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE gold.employee_skill_gaps
# MAGIC COMMENT 'Skill gap analysis per employee against the required skills for (a) the current job title and (b) the proposed or approved mobility target role. Requirements come from hr4u_role_skill_requirements (SYNTHETIC role framework, batch01). gap_status: Meets Requirement / Below Required / Missing. recommended_courses = active LMS courses for that skill the employee has not completed. Factual input for development conversations, not an assessment.'
# MAGIC AS
# MAGIC WITH target AS (
# MAGIC   SELECT employee_id, target_role FROM (
# MAGIC     SELECT employee_id, target_role, row_number() OVER (PARTITION BY employee_id ORDER BY effective_date DESC) AS rn
# MAGIC     FROM silver.hr4u_employee_mobility WHERE target_role IS NOT NULL AND mobility_status IN ('Proposed', 'Approved')) WHERE rn = 1),
# MAGIC roles AS (
# MAGIC   SELECT employee_id, job_title AS role_name, 'Current Role' AS requirement_type FROM silver.hr4u_employees
# MAGIC   UNION ALL SELECT employee_id, target_role, 'Target Role' FROM target),
# MAGIC prof AS (SELECT employee_id, skill_name, max(proficiency_score) AS score FROM silver.hr4u_employee_skills GROUP BY ALL),
# MAGIC gaps AS (
# MAGIC   SELECT r.employee_id, r.requirement_type, r.role_name, q.skill_name, q.skill_category, q.importance,
# MAGIC     q.required_proficiency_level, q.required_proficiency_score, p.score AS employee_proficiency_score
# MAGIC   FROM roles r JOIN silver.hr4u_role_skill_requirements q ON q.role_name = r.role_name
# MAGIC   LEFT JOIN prof p ON p.employee_id = r.employee_id AND p.skill_name = q.skill_name),
# MAGIC lrn AS (
# MAGIC   SELECT a.employee_id, c.skill_name,
# MAGIC     sum(IF(a.learning_status = 'Completed', 1, 0)) AS courses_completed,
# MAGIC     sum(IF(a.learning_status IN ('In Progress', 'Enrolled'), 1, 0)) AS courses_in_progress
# MAGIC   FROM silver.lms_learning_activity a JOIN silver.lms_courses c ON c.course_id = a.course_id GROUP BY ALL),
# MAGIC rec AS (
# MAGIC   SELECT g.employee_id, g.skill_name, array_sort(collect_set(c.course_name)) AS recommended_courses
# MAGIC   FROM (SELECT DISTINCT employee_id, skill_name FROM gaps) g
# MAGIC   JOIN silver.lms_courses c ON c.skill_name = g.skill_name AND c.course_status = 'Active'
# MAGIC   LEFT JOIN silver.lms_learning_activity a ON a.employee_id = g.employee_id AND a.course_id = c.course_id AND a.learning_status = 'Completed'
# MAGIC   WHERE a.learning_activity_id IS NULL GROUP BY ALL)
# MAGIC SELECT g.employee_id, e.employee_name, e.manager_id, e.department_name, e.job_title, g.requirement_type, g.role_name,
# MAGIC   g.skill_name, g.skill_category, g.importance, g.required_proficiency_level, g.required_proficiency_score,
# MAGIC   CASE g.employee_proficiency_score WHEN 1 THEN 'Beginner' WHEN 2 THEN 'Intermediate' WHEN 3 THEN 'Advanced' WHEN 4 THEN 'Expert' END AS employee_proficiency_level,
# MAGIC   g.employee_proficiency_score,
# MAGIC   CAST(greatest(g.required_proficiency_score - coalesce(g.employee_proficiency_score, 0), 0) AS INT) AS proficiency_gap,
# MAGIC   CASE WHEN g.employee_proficiency_score IS NULL THEN 'Missing'
# MAGIC        WHEN g.employee_proficiency_score < g.required_proficiency_score THEN 'Below Required'
# MAGIC        ELSE 'Meets Requirement' END AS gap_status,
# MAGIC   CAST(coalesce(l.courses_completed, 0) AS INT) AS related_courses_completed,
# MAGIC   CAST(coalesce(l.courses_in_progress, 0) AS INT) AS related_courses_in_progress,
# MAGIC   coalesce(rec.recommended_courses, CAST(array() AS ARRAY<STRING>)) AS recommended_courses,
# MAGIC   current_date() AS reporting_date
# MAGIC FROM gaps g
# MAGIC JOIN silver.hr4u_employees e ON e.employee_id = g.employee_id
# MAGIC LEFT JOIN lrn l ON l.employee_id = g.employee_id AND l.skill_name = g.skill_name
# MAGIC LEFT JOIN rec ON rec.employee_id = g.employee_id AND rec.skill_name = g.skill_name;

# COMMAND ----------

# DBTITLE 1,gold employee 90 and 180 day summary
# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE gold.employee_90_180_day_summary
# MAGIC COMMENT 'AI-ready factual employee summary for 1:1 preparation. Grain: one row per employee per reporting_period (LAST_90_DAYS, LAST_180_DAYS). summary_facts and discussion_flags are generated only from the metrics in the row; no ratings or judgements. Performance ratings are deliberately excluded.'
# MAGIC AS
# MAGIC WITH p AS (SELECT * FROM reporting_periods WHERE reporting_period IN ('LAST_90_DAYS', 'LAST_180_DAYS')),
# MAGIC iss AS (
# MAGIC   SELECT i.assignee_id AS employee_id, p.reporting_period,
# MAGIC     collect_set(IF(i.created_date <= p.period_end AND (i.resolved_date IS NULL OR i.resolved_date >= p.period_start), i.project_name, NULL)) AS projects,
# MAGIC     collect_set(IF(i.created_date <= p.period_end AND (i.resolved_date IS NULL OR i.resolved_date >= p.period_start), i.sprint_id, NULL)) AS sprints,
# MAGIC     sum(IF(i.resolved_date BETWEEN p.period_start AND p.period_end, 1, 0)) AS jira_items_completed,
# MAGIC     sum(IF(i.resolved_date BETWEEN p.period_start AND p.period_end, i.story_points, 0)) AS story_points_completed,
# MAGIC     sum(IF(i.status_category <> 'Done', 1, 0)) AS active_jira_items,
# MAGIC     sum(IF(i.status_category <> 'Done' AND i.due_date < current_date(), 1, 0)) AS overdue_jira_items,
# MAGIC     sum(IF(i.status_category <> 'Done' AND i.priority IN ('High', 'Highest'), 1, 0)) AS open_high_priority_items,
# MAGIC     sum(IF(i.is_blocked, 1, 0)) AS blocked_jira_items,
# MAGIC     slice(reverse(array_sort(collect_list(IF(i.resolved_date BETWEEN p.period_start AND p.period_end,
# MAGIC       named_struct('d', i.resolved_date, 't', concat(i.issue_key, ': ', i.summary)), NULL)))), 1, 5) AS recent_completed
# MAGIC   FROM silver.jira_issues i CROSS JOIN p GROUP BY ALL),
# MAGIC wl AS (
# MAGIC   SELECT w.employee_id, p.reporting_period, sum(w.time_spent_hours) AS worklog_hours,
# MAGIC     sum(IF(w.is_weekend, w.time_spent_hours, 0)) AS weekend_worklog_hours,
# MAGIC     sum(IF(w.is_after_hours, w.time_spent_hours, 0)) AS after_hours_worklog_hours,
# MAGIC     collect_set(i.project_name) AS projects, collect_set(i.sprint_id) AS sprints
# MAGIC   FROM silver.jira_worklogs w JOIN p ON w.work_date BETWEEN p.period_start AND p.period_end
# MAGIC   LEFT JOIN silver.jira_issues i ON i.issue_id = w.issue_id GROUP BY ALL),
# MAGIC inc AS (
# MAGIC   SELECT i.assigned_to_id AS employee_id, p.reporting_period,
# MAGIC     sum(IF(to_date(i.opened_date) BETWEEN p.period_start AND p.period_end, 1, 0)) AS incidents_assigned,
# MAGIC     sum(IF(i.is_resolved AND to_date(i.resolved_date) BETWEEN p.period_start AND p.period_end, 1, 0)) AS incidents_resolved,
# MAGIC     sum(IF(i.is_resolved AND to_date(i.resolved_date) BETWEEN p.period_start AND p.period_end AND i.sla_status = 'Met', 1, 0)) AS sla_met,
# MAGIC     sum(IF(i.is_resolved AND to_date(i.resolved_date) BETWEEN p.period_start AND p.period_end AND i.sla_status IN ('Met', 'Breached'), 1, 0)) AS sla_measured,
# MAGIC     sum(IF(i.is_open, 1, 0)) AS open_incidents,
# MAGIC     sum(IF(to_date(i.opened_date) BETWEEN p.period_start AND p.period_end AND i.is_after_hours, 1, 0)) AS after_hours_incidents
# MAGIC   FROM silver.servicenow_incidents i CROSS JOIN p WHERE i.assigned_to_id IS NOT NULL GROUP BY ALL),
# MAGIC req AS (
# MAGIC   SELECT r.assigned_to_id AS employee_id, p.reporting_period,
# MAGIC     sum(IF(r.is_completed AND to_date(r.completion_date) BETWEEN p.period_start AND p.period_end, 1, 0)) AS requests_completed,
# MAGIC     sum(IF(r.is_open, 1, 0)) AS open_requests
# MAGIC   FROM silver.servicenow_requests r CROSS JOIN p WHERE r.assigned_to_id IS NOT NULL GROUP BY ALL),
# MAGIC tsk AS (
# MAGIC   SELECT t.assigned_to_id AS employee_id, p.reporting_period,
# MAGIC     sum(IF(t.is_completed AND to_date(t.completed_date) BETWEEN p.period_start AND p.period_end, 1, 0)) AS tasks_completed
# MAGIC   FROM silver.servicenow_tasks t CROSS JOIN p WHERE t.assigned_to_id IS NOT NULL GROUP BY ALL),
# MAGIC la AS (
# MAGIC   SELECT a.employee_id, p.reporting_period,
# MAGIC     sum(IF(a.completion_date BETWEEN p.period_start AND p.period_end, 1, 0)) AS courses_completed,
# MAGIC     sum(IF(a.completion_date BETWEEN p.period_start AND p.period_end, a.learning_hours, 0)) AS learning_hours,
# MAGIC     avg(IF(a.completion_date BETWEEN p.period_start AND p.period_end, a.assessment_score, NULL)) AS avg_assessment_score,
# MAGIC     sum(IF(a.learning_status IN ('In Progress', 'Enrolled'), 1, 0)) AS pending_learning_items,
# MAGIC     collect_set(IF(a.completion_date BETWEEN p.period_start AND p.period_end, c.course_name, NULL)) AS courses_completed_names
# MAGIC   FROM silver.lms_learning_activity a LEFT JOIN silver.lms_courses c ON c.course_id = a.course_id CROSS JOIN p GROUP BY ALL),
# MAGIC ct AS (
# MAGIC   SELECT c.employee_id, p.reporting_period,
# MAGIC     sum(IF(c.issue_date BETWEEN p.period_start AND p.period_end, 1, 0)) AS certifications_earned,
# MAGIC     collect_set(IF(c.issue_date BETWEEN p.period_start AND p.period_end, c.certification_name, NULL)) AS certifications_earned_names,
# MAGIC     sum(IF(c.certification_status = 'Active' AND (c.expiry_date IS NULL OR c.expiry_date >= current_date()), 1, 0)) AS active_certifications,
# MAGIC     sum(IF(c.certification_status = 'Active' AND c.expiry_date BETWEEN current_date() AND date_add(current_date(), 90), 1, 0)) AS certifications_expiring_90d
# MAGIC   FROM silver.lms_certifications c CROSS JOIN p GROUP BY ALL),
# MAGIC m AS (
# MAGIC   SELECT e.employee_id, e.employee_name, e.employee_display_name, e.manager_id, e.manager_name, e.department_name, e.job_title,
# MAGIC     e.job_level, e.location, e.employment_status, p.reporting_period, p.period_start, p.period_end,
# MAGIC     array_sort(array_union(coalesce(iss.projects, array()), coalesce(wl.projects, array()))) AS projects_contributed,
# MAGIC     size(array_union(coalesce(iss.sprints, array()), coalesce(wl.sprints, array()))) AS sprints_participated,
# MAGIC     coalesce(iss.jira_items_completed, 0) AS jira_items_completed,
# MAGIC     CAST(coalesce(iss.story_points_completed, 0) AS DECIMAL(10,2)) AS story_points_completed,
# MAGIC     coalesce(iss.active_jira_items, 0) AS active_jira_items, coalesce(iss.overdue_jira_items, 0) AS overdue_jira_items,
# MAGIC     coalesce(iss.open_high_priority_items, 0) AS open_high_priority_items,
# MAGIC     coalesce(iss.blocked_jira_items, 0) AS blocked_jira_items,
# MAGIC     CAST(coalesce(wl.worklog_hours, 0) AS DECIMAL(10,2)) AS worklog_hours,
# MAGIC     CAST(coalesce(wl.weekend_worklog_hours, 0) AS DECIMAL(10,2)) AS weekend_worklog_hours,
# MAGIC     CAST(coalesce(wl.after_hours_worklog_hours, 0) AS DECIMAL(10,2)) AS after_hours_worklog_hours,
# MAGIC     coalesce(inc.incidents_assigned, 0) AS incidents_assigned, coalesce(inc.incidents_resolved, 0) AS incidents_resolved,
# MAGIC     CAST(100 * inc.sla_met / nullif(inc.sla_measured, 0) AS DECIMAL(5,2)) AS sla_met_percentage,
# MAGIC     coalesce(inc.open_incidents, 0) AS open_incidents, coalesce(inc.after_hours_incidents, 0) AS after_hours_incidents,
# MAGIC     coalesce(req.requests_completed, 0) AS requests_completed, coalesce(req.open_requests, 0) AS open_requests,
# MAGIC     coalesce(tsk.tasks_completed, 0) AS tasks_completed,
# MAGIC     coalesce(la.courses_completed, 0) AS courses_completed,
# MAGIC     CAST(coalesce(la.learning_hours, 0) AS DECIMAL(10,2)) AS learning_hours,
# MAGIC     CAST(la.avg_assessment_score AS DECIMAL(5,2)) AS avg_assessment_score,
# MAGIC     coalesce(la.pending_learning_items, 0) AS pending_learning_items,
# MAGIC     coalesce(la.courses_completed_names, array()) AS courses_completed_names,
# MAGIC     coalesce(ct.certifications_earned, 0) AS certifications_earned,
# MAGIC     coalesce(ct.certifications_earned_names, array()) AS certifications_earned_names,
# MAGIC     coalesce(ct.active_certifications, 0) AS active_certifications,
# MAGIC     coalesce(ct.certifications_expiring_90d, 0) AS certifications_expiring_90d,
# MAGIC     transform(coalesce(iss.recent_completed, array()), x -> x.t) AS recent_completed_items
# MAGIC   FROM silver.hr4u_employees e CROSS JOIN p
# MAGIC   LEFT JOIN iss ON iss.employee_id = e.employee_id AND iss.reporting_period = p.reporting_period
# MAGIC   LEFT JOIN wl ON wl.employee_id = e.employee_id AND wl.reporting_period = p.reporting_period
# MAGIC   LEFT JOIN inc ON inc.employee_id = e.employee_id AND inc.reporting_period = p.reporting_period
# MAGIC   LEFT JOIN req ON req.employee_id = e.employee_id AND req.reporting_period = p.reporting_period
# MAGIC   LEFT JOIN tsk ON tsk.employee_id = e.employee_id AND tsk.reporting_period = p.reporting_period
# MAGIC   LEFT JOIN la ON la.employee_id = e.employee_id AND la.reporting_period = p.reporting_period
# MAGIC   LEFT JOIN ct ON ct.employee_id = e.employee_id AND ct.reporting_period = p.reporting_period)
# MAGIC SELECT m.*,
# MAGIC   filter(array(
# MAGIC     IF(m.jira_items_completed + m.active_jira_items > 0 OR m.worklog_hours > 0, 'Jira', NULL),
# MAGIC     IF(m.incidents_assigned + m.incidents_resolved + m.requests_completed + m.tasks_completed + m.open_incidents + m.open_requests > 0, 'ServiceNow', NULL),
# MAGIC     IF(m.courses_completed + m.pending_learning_items + m.certifications_earned + m.active_certifications > 0, 'LMS', NULL)), x -> x IS NOT NULL) AS data_sources_with_activity,
# MAGIC   concat('Reporting period ', m.period_start, ' to ', m.period_end, '. ',
# MAGIC     'Jira: ', m.jira_items_completed, ' items completed (', m.story_points_completed, ' story points) across ',
# MAGIC     size(m.projects_contributed), ' project(s)', IF(size(m.projects_contributed) > 0, concat(' [', array_join(m.projects_contributed, ', '), ']'), ''),
# MAGIC     ' and ', m.sprints_participated, ' sprint(s); ', m.worklog_hours, ' worklog hours; ', m.active_jira_items, ' open items (', m.overdue_jira_items, ' past due, ', m.blocked_jira_items, ' blocked). ',
# MAGIC     'ServiceNow: ', m.incidents_resolved, ' incidents resolved', IF(m.sla_met_percentage IS NOT NULL, concat(' (SLA met ', m.sla_met_percentage, '%)'), ''),
# MAGIC     ', ', m.requests_completed, ' requests and ', m.tasks_completed, ' tasks completed. ',
# MAGIC     'LMS: ', m.courses_completed, ' courses completed (', m.learning_hours, ' hours), ', m.certifications_earned, ' certification(s) earned, ',
# MAGIC     m.active_certifications, ' active certification(s), ', m.pending_learning_items, ' learning item(s) pending.') AS summary_facts,
# MAGIC   filter(array(
# MAGIC     IF(m.overdue_jira_items > 0, concat(m.overdue_jira_items, ' open Jira item(s) are past their due date'), NULL),
# MAGIC     IF(m.open_high_priority_items > 0, concat(m.open_high_priority_items, ' open high-priority Jira item(s)'), NULL),
# MAGIC     IF(m.blocked_jira_items > 0, concat(m.blocked_jira_items, ' Jira item(s) currently Blocked'), NULL),
# MAGIC     IF(m.weekend_worklog_hours > 0, concat(m.weekend_worklog_hours, ' worklog hours recorded on weekends'), NULL),
# MAGIC     IF(m.after_hours_worklog_hours > 0, concat(m.after_hours_worklog_hours, ' worklog hours started before 08:00 or after 19:00'), NULL),
# MAGIC     IF(m.after_hours_incidents > 0, concat(m.after_hours_incidents, ' assigned incident(s) opened outside 08:00-19:00 or on weekends'), NULL),
# MAGIC     IF(size(m.projects_contributed) >= 3, concat('Contributed to ', size(m.projects_contributed), ' projects in the period'), NULL),
# MAGIC     IF(m.pending_learning_items > 0, concat(m.pending_learning_items, ' learning item(s) in progress or not started'), NULL),
# MAGIC     IF(m.certifications_expiring_90d > 0, concat(m.certifications_expiring_90d, ' active certification(s) expire within 90 days'), NULL),
# MAGIC     IF(m.courses_completed = 0 AND m.certifications_earned = 0, 'No course completions or certifications recorded in the period', NULL)
# MAGIC   ), x -> x IS NOT NULL) AS discussion_flags,
# MAGIC   current_date() AS reporting_date
# MAGIC FROM m;

# COMMAND ----------

# DBTITLE 1,Data freshness table (from Silver) and Gold audit log
dbutils.widgets.text("run_id", "", "Run ID (blank = new)")
RUN_ID = dbutils.widgets.get("run_id") or new_run_id()
started = datetime.now()
# Gold reads Silver only: Bronze ingest time and source file come from the Silver lineage columns.
rows = []
for src, cfg in SOURCES.items():
    col = BUSINESS_DATE.get(src)
    s = spark.sql(f"""SELECT count(*), max(_bronze_ingest_ts), count(DISTINCT _source_file), sum(IF(_is_synthetic, 1, 0)),
        max(_silver_updated_ts), {f'max(CAST({col} AS DATE))' if col else 'CAST(NULL AS DATE)'} FROM {fq(SILVER_PREFIX + src)}""").first()
    rows.append((cfg["system"], src, int(s[0]), s[1], int(s[2]), int(s[3] or 0), s[4], s[5]))
schema = ("source_system STRING, source_entity STRING, silver_rows BIGINT, last_bronze_ingest_ts TIMESTAMP, source_files BIGINT, "
          "synthetic_rows BIGINT, last_silver_update_ts TIMESTAMP, latest_business_date DATE")
fresh = (spark.createDataFrame(rows, schema)
    .withColumn("gold_built_at", F.current_timestamp())
    .withColumn("days_since_latest_business_date", F.datediff(F.current_date(), "latest_business_date"))
    .withColumn("hours_since_bronze_ingest", F.round((F.unix_timestamp(F.current_timestamp()) - F.unix_timestamp("last_bronze_ingest_ts")) / 3600, 1)))
fresh.write.mode("overwrite").option("overwriteSchema", "true").saveAsTable(fq(GOLD_PREFIX + "data_freshness"))
spark.sql(f"COMMENT ON TABLE {fq(GOLD_PREFIX + 'data_freshness')} IS 'Data freshness per source: Bronze ingest time, Silver update time, latest business event date and synthetic row share. Rebuilt on every Gold run.'")

GOLD_TABLES = ["employee_360", "employee_career", "employee_learning", "employee_operations", "employee_performance", "employee_workload",
               "manager_team_summary", "employee_activity", "employee_skills", "employee_skill_gaps", "employee_90_180_day_summary", "data_freshness"]
for t in GOLD_TABLES:
    log_audit(RUN_ID, "gold", f"gold.{t}", "SUCCESS", spark.table(fq(GOLD_PREFIX + t)).count(), started)
display(fresh.orderBy("source_system", "source_entity"))

# COMMAND ----------

# DBTITLE 1,Row counts and grain checks
# MAGIC %sql
# MAGIC SELECT 'gold.employee_360' AS table_name, count(*) AS row_count, count(*) - count(DISTINCT employee_id) AS grain_duplicates FROM gold.employee_360
# MAGIC UNION ALL SELECT 'gold.employee_career', count(*), count(*) - count(DISTINCT mobility_id) FROM gold.employee_career
# MAGIC UNION ALL SELECT 'gold.employee_learning', count(*), count(*) - count(DISTINCT employee_id, reporting_period) FROM gold.employee_learning
# MAGIC UNION ALL SELECT 'gold.employee_operations', count(*), count(*) - count(DISTINCT employee_id, reporting_period) FROM gold.employee_operations
# MAGIC UNION ALL SELECT 'gold.employee_performance', count(*), count(*) - count(DISTINCT review_id) FROM gold.employee_performance
# MAGIC UNION ALL SELECT 'gold.employee_workload', count(*), count(*) - count(DISTINCT employee_id, project_id, sprint_id) FROM gold.employee_workload
# MAGIC UNION ALL SELECT 'gold.manager_team_summary', count(*), count(*) - count(DISTINCT manager_id, reporting_period) FROM gold.manager_team_summary
# MAGIC UNION ALL SELECT 'gold.employee_activity', count(*), count(*) - count(DISTINCT activity_id) FROM gold.employee_activity
# MAGIC UNION ALL SELECT 'gold.employee_skills', count(*), count(*) - count(DISTINCT employee_id, skill_name, skill_source) FROM gold.employee_skills
# MAGIC UNION ALL SELECT 'gold.employee_90_180_day_summary', count(*), count(*) - count(DISTINCT employee_id, reporting_period) FROM gold.employee_90_180_day_summary
# MAGIC UNION ALL SELECT 'gold.employee_skill_gaps', count(*), count(*) - count(DISTINCT employee_id, requirement_type, role_name, skill_name) FROM gold.employee_skill_gaps
# MAGIC UNION ALL SELECT 'gold.data_freshness', count(*), count(*) - count(DISTINCT source_entity) FROM gold.data_freshness;