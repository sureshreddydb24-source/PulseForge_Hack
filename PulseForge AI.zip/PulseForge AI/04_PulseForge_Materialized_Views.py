# Databricks notebook source
# DBTITLE 1,Materialized views overview
# MAGIC %md
# MAGIC # PulseForge AI - dashboard materialized views
# MAGIC One materialized view `team_1.dashboard.mv_<name>` per Gold table. These are the dashboard's data sources. Each keeps the Gold table's columns, so dashboard widgets can use the same field names as the existing `gold_*` tables.
# MAGIC Run by the **PulseForge - Refresh Materialized Views** job, which starts automatically when Gold is rebuilt. Each view is refreshed, or recreated if its Gold table's columns changed. Every refresh is logged to `team_1.ops.pipeline_audit_log`. For the dashboard's freshness panel, use `dashboard.mv_data_freshness`, which is built from the Gold table `gold.data_freshness`.

# COMMAND ----------

# DBTITLE 1,Load shared config
# MAGIC %run ./00_PulseForge_Config

# COMMAND ----------

# DBTITLE 1,Create or refresh dashboard materialized views
dbutils.widgets.text("run_id", "", "Run ID (blank = new)")
RUN_ID = dbutils.widgets.get("run_id") or new_run_id()
GOLD_TABLES = ["employee_360", "employee_career", "employee_learning", "employee_operations", "employee_performance",
               "employee_workload", "manager_team_summary", "employee_activity", "employee_skills", "employee_skill_gaps",
               "employee_90_180_day_summary", "data_freshness"]
results = []
for t in GOLD_TABLES:
    gold, mv = fq(GOLD_PREFIX + t), fq(MV_PREFIX + t)
    started = datetime.now()
    try:
        if spark.catalog.tableExists(mv) and spark.table(mv).columns == spark.table(gold).columns:
            spark.sql(f"REFRESH MATERIALIZED VIEW {mv}")
            action = "REFRESHED"
        else:  # new view, or the Gold schema changed -> recreate so the view keeps the Gold columns
            comment = (spark.sql(f"DESCRIBE TABLE EXTENDED {gold}").filter("col_name = 'Comment'").select("data_type").first() or [""])[0]
            comment = (f"Dashboard materialized view over gold.{t}. " + (comment or "")).replace("'", "")
            spark.sql(f"CREATE OR REPLACE MATERIALIZED VIEW {mv} COMMENT '{comment}' AS SELECT * FROM {gold}")
            action = "CREATED"
        n = spark.table(mv).count()
        log_audit(RUN_ID, "mv", f"dashboard.mv_{t}", "SUCCESS", n, started, action)
        results.append((mv, action, n, ""))
    except Exception as ex:
        log_audit(RUN_ID, "mv", f"dashboard.mv_{t}", "FAILED", None, started, str(ex))
        results.append((mv, "FAILED", None, str(ex)[:300]))

# Every materialized view reads only from a team_1.gold table (strict medallion: files -> Bronze -> Silver -> Gold -> MV).
display(spark.createDataFrame(results, "materialized_view STRING, action STRING, rows BIGINT, error STRING"))
if any(r[1] == "FAILED" for r in results):
    raise RuntimeError("One or more materialized views failed")

# COMMAND ----------

# DBTITLE 1,Reconcile view row counts with Gold
rows = [(t, spark.table(fq(GOLD_PREFIX + t)).count(), spark.table(fq(MV_PREFIX + t)).count()) for t in GOLD_TABLES]
display(spark.createDataFrame([(a, b, c, b == c) for a, b, c in rows], "name STRING, gold_rows BIGINT, mv_rows BIGINT, match BOOLEAN"))