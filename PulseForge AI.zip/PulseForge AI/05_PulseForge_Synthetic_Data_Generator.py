# Databricks notebook source
# DBTITLE 1,Synthetic data overview
# MAGIC %md
# MAGIC # PulseForge AI - synthetic data batch 01 (SYNTHETIC, demo only)
# MAGIC Fills the data gaps found during profiling and adds more volume for the manager dashboard. **Every record written here is synthetic.** Files are named `<source>_synthetic_batch01.csv`, and Silver flags their rows with `_is_synthetic = true`. The original CSVs are never modified.
# MAGIC
# MAGIC | Gap found | What this batch adds |
# MAGIC | --- | --- |
# MAGIC | No employee skills file | `hr4u_employee_skills` - skill profile with proficiency for every employee |
# MAGIC | No role skill requirements | `hr4u_role_skill_requirements` - required skills per job title and per mobility target role |
# MAGIC | No manager-to-user access mapping | `hr4u_manager_access` - workspace user email to manager scope (for row-level security) |
# MAGIC | Anand and Kavitha (example questions) missing | 25 new employees, including Anand Sharma and Kavitha Nair |
# MAGIC | No employee history changes | Promotions and a transfer for existing employees (drives SCD Type 2) |
# MAGIC | No Jira Blocked status | New and updated issues with status `Blocked` |
# MAGIC | Worklogs have dates but no times | New worklogs carry `work_start_time` (lands in `_rescued_data`, parsed in Silver) |
# MAGIC | Thin recent volume | More Jira, ServiceNow and LMS activity up to the batch date, including cloud certifications |
# MAGIC
# MAGIC The run is deterministic (fixed seed). Re-running rewrites the same files with identical content, so Silver sees no changes.

# COMMAND ----------

# DBTITLE 1,Setup, originals and helpers
import numpy as np, pandas as pd
from datetime import date, datetime, timedelta

SRC = "/Volumes/team_1/default/pulseforge/PulseForge"
BATCH = "synthetic_batch01"
AS_OF = date(2026, 11, 17)            # last activity date in this batch
rng = np.random.default_rng(20261118)  # fixed seed -> reproducible files
OUT = {}                               # source name -> DataFrame to write

def rd(name):  # original files only (exact name, never the synthetic ones)
    return pd.read_csv(f"{SRC}/{name}.csv", dtype=str, keep_default_na=False)

def choice(xs, p=None):
    xs = list(xs)
    return xs[int(rng.choice(len(xs), p=p))]

def rdate(a, b):
    span = max((b - a).days, 0)
    return a + timedelta(days=int(rng.integers(0, span + 1)))

def d(s):  # 'yyyy-mm-dd...' -> date
    return datetime.strptime(s[:10], "%Y-%m-%d").date()

def rts(day, hour_lo=8, hour_hi=19):
    return datetime(day.year, day.month, day.day, int(rng.integers(hour_lo, hour_hi)), int(rng.integers(0, 60)), int(rng.integers(0, 60)))

def fmt_ts(x): return x.strftime("%Y-%m-%d %H:%M:%S")

emp0 = rd("hr4u_employees")
for c in ["hr4u_employee_goals", "hr4u_employee_mobility", "hr4u_performance_reviews", "jira_issues", "jira_sprints",
          "jira_worklogs", "lms_courses", "lms_learning_activity", "lms_certifications", "servicenow_incidents",
          "servicenow_requests", "servicenow_tasks"]:
    globals()[c] = rd(c)

def family(title):
    t = title.lower()
    if "data engineer" in t: return "data"
    if "software engineer" in t: return "software"
    if any(k in t for k in ["service desk", "desktop support", "application support", "it support"]): return "support"
    if "network" in t: return "network"
    if "database" in t: return "dba"
    if "iam" in t: return "iam"
    if any(k in t for k in ["hr ", "hr", "talent", "payroll", "l&d"]) and "chief" not in t: return "hr"
    if any(k in t for k in ["financ", "account", "fp&a", "tax", "controller"]): return "finance"
    return "leadership"

# Skill names are aligned with lms_courses.skill_name so skill gaps can recommend real courses.
FAMILY_SKILLS = {
    "data": ["Apache Spark", "SQL", "Python", "Databricks", "Data Engineering", "Azure Cloud", "AWS Cloud", "Machine Learning"],
    "software": ["Python", "React", "Kubernetes", "Containers", "AWS Cloud", "Application Security", "SQL", "Agile"],
    "support": ["IT Service Management", "ServiceNow", "Networking", "IAM", "Communication", "Time Management"],
    "network": ["Networking", "Information Security", "Azure Cloud", "IT Service Management"],
    "dba": ["Database Administration", "SQL", "Azure Cloud", "Data Privacy"],
    "iam": ["IAM", "Information Security", "Azure Cloud", "Compliance"],
    "hr": ["People Analytics", "Recruitment", "Communication", "Compliance", "Emotional Intelligence"],
    "finance": ["Financial Modelling", "Accounting", "Compliance", "SQL"],
    "leadership": ["Leadership", "Mentoring", "Project Management", "Public Speaking", "Agile", "Communication"],
}
SKILL_CATEGORY = dict(zip(lms_courses.skill_name, lms_courses.course_category))
LEVELS = {1: "Beginner", 2: "Intermediate", 3: "Advanced", 4: "Expert"}

def title_level(title):
    t = title.lower()
    if t.startswith("associate"): return "L1"
    if t.startswith("senior"): return "L3"
    if t.startswith("lead"): return "L4"
    return "L2"
print("originals loaded:", len(emp0), "employees")

# COMMAND ----------

# DBTITLE 1,HR4U - new employees and history changes
FIRST = ["Arjun", "Priya", "Vikram", "Divya", "Karthik", "Meera", "Rohit", "Pooja", "Nikhil", "Swathi", "Harish", "Neha",
         "Varun", "Ishita", "Manoj", "Deepa", "Sandeep", "Ritu", "Ganesh", "Anjali", "Kiran", "Bhavana", "Tarun"]
LAST = ["Reddy", "Iyer", "Patel", "Menon", "Rao", "Pillai", "Joshi", "Kapoor", "Nair", "Bose", "Desai", "Shetty", "Gupta", "Verma"]
existing_names = set(emp0.employee_name)
names = []
while len(names) < 23:
    n = f"{choice(FIRST)} {choice(LAST)}"
    if n not in existing_names and n not in names and n not in ("Anand Sharma", "Kavitha Nair"):
        names.append(n)

team_plan = [("Anand Sharma", "EMP004", "Data Engineer"), ("Kavitha Nair", "EMP003", "Senior Software Engineer")]
mgr_slots = ["EMP003"] * 5 + ["EMP004"] * 5 + ["EMP006"] * 7 + ["EMP007"] * 2 + ["EMP008"] * 4
for n, m in zip(names, mgr_slots):
    titles = sorted(set(emp0.loc[emp0.manager_id == m, "job_title"]))
    team_plan.append((n, m, choice(titles)))

existing_ids = set(emp0.employee_id)
locs = emp0[["location", "country"]].drop_duplicates().values.tolist()
rows = []
for i, (name, mgr, title) in enumerate(team_plan):
    eid = f"EMP{401 + i}"
    assert eid not in existing_ids
    peer = emp0[emp0.manager_id == mgr].iloc[0]
    mrow = emp0[emp0.employee_id == mgr].iloc[0]
    loc = choice(locs)
    joined = rdate(date(2018, 1, 1), date(2026, 9, 30))
    rows.append({"employee_id": eid, "employee_name": name, "email": name.lower().replace(" ", ".") + "@pulseforge-demo.com",
        "department_id": peer.department_id, "department_name": peer.department_name, "business_unit": peer.business_unit,
        "job_title": title, "job_level": title_level(title), "manager_id": mgr, "manager_name": mrow.employee_name,
        "location": loc[0], "country": loc[1], "employment_type": "Contract" if rng.random() < 0.1 else "Permanent",
        "joining_date": str(joined), "employment_status": "On Leave" if i == 12 else "Active",
        "experience_years": f"{(AS_OF - joined).days / 365 + rng.uniform(0, 8):.1f}", "cost_center": peer.cost_center,
        "last_updated_date": str(max(joined, date(2026, 10, 1)))})
new_emp = pd.DataFrame(rows)

# History changes on existing employees (promotions + one transfer) -> SCD Type 2 versions in Silver.
upd = []
for title_from, title_to, lvl in [("Software Engineer", "Senior Software Engineer", "L3"), ("Data Engineer", "Senior Data Engineer", "L3")]:
    for _, r in emp0[(emp0.job_title == title_from) & (emp0.employment_status == "Active")].head(2).iterrows():
        r = r.copy(); r["job_title"], r["job_level"], r["last_updated_date"] = title_to, lvl, "2026-11-15"
        upd.append(r)
mover = emp0[(emp0.manager_id == "EMP003") & (emp0.job_title == "Software Engineer")].iloc[-1].copy()
d210 = emp0[emp0.department_id == "D210"].iloc[0]
mover["department_id"], mover["department_name"], mover["manager_id"], mover["manager_name"] = "D210", d210.department_name, "EMP004", "Shreya Bhat"
mover["job_title"], mover["last_updated_date"] = "Data Engineer", "2026-11-12"
upd.append(mover)
upd_emp = pd.DataFrame(upd)[emp0.columns]
OUT["hr4u_employees"] = pd.concat([upd_emp, new_emp[emp0.columns]], ignore_index=True)

# Current view of all employees after this batch (used by every generator below)
all_emp = pd.concat([emp0[~emp0.employee_id.isin(upd_emp.employee_id)], upd_emp, new_emp[emp0.columns]], ignore_index=True)
all_emp["family"] = all_emp.job_title.map(family)
active = all_emp[all_emp.employment_status == "Active"]
print(f"new employees={len(new_emp)}, history changes={len(upd_emp)}, total employees={len(all_emp)}")
display(OUT["hr4u_employees"][["employee_id", "employee_name", "job_title", "job_level", "manager_id", "department_name", "last_updated_date"]])

# COMMAND ----------

# DBTITLE 1,HR4U - skills, role requirements, access, reviews, goals, mobility
# Employee skill profile
lvl_num = {"L1": 1, "L2": 2, "L3": 3}
sk_rows = []
for _, e in all_emp.iterrows():
    fam = FAMILY_SKILLS[e.family]
    picked = [s for s in fam[:4] if rng.random() < 0.85] + list(rng.choice(fam[4:] or fam, size=min(2, len(fam[4:] or fam)), replace=False))
    if lvl_num.get(e.job_level, 4) >= 4 and e.family != "leadership":
        picked += ["Leadership", "Mentoring"]
    base = lvl_num.get(e.job_level, 3)
    for s in dict.fromkeys(picked):
        score = int(np.clip(base + rng.choice([-1, 0, 0, 1]), 1, 4))
        sk_rows.append({"employee_skill_id": f"ESK{len(sk_rows) + 1:05d}", "employee_id": e.employee_id, "skill_name": s,
            "skill_category": SKILL_CATEGORY.get(s, "Technical"), "proficiency_level": LEVELS[score], "proficiency_score": str(score),
            "experience_years": f"{min(float(e.experience_years), rng.uniform(0.5, 10)):.1f}",
            "last_assessed_date": str(rdate(date(2025, 6, 1), AS_OF)), "assessment_source": choice(["Manager", "Self", "Manager"]),
            "last_updated_date": str(AS_OF)})
OUT["hr4u_employee_skills"] = pd.DataFrame(sk_rows)

# Role skill requirements: every current job title + every mobility target role
TARGET_ROLE_SKILLS = {
    "Cloud Solutions Architect": ["Azure Cloud", "AWS Cloud", "Kubernetes", "Containers", "Application Security"],
    "Cloud Operations Engineer": ["Azure Cloud", "AWS Cloud", "Kubernetes", "Networking"],
    "Security Analyst": ["Information Security", "Application Security", "IAM", "Compliance"],
    "Machine Learning Engineer": ["Machine Learning", "Python", "Apache Spark", "Databricks"],
    "Data Scientist": ["Machine Learning", "Python", "SQL", "Databricks"],
    "Data Architect": ["Data Engineering", "Databricks", "Azure Cloud", "SQL", "Apache Spark"],
    "Product Manager": ["Project Management", "Agile", "Communication", "Leadership"],
    "Business Analyst": ["SQL", "Project Management", "Communication", "Agile"],
    "HR Manager": ["People Analytics", "Leadership", "Recruitment", "Compliance"],
    "People Analytics Lead": ["People Analytics", "SQL", "Python", "Leadership"],
    "Engineering Manager": ["Leadership", "Agile", "Project Management", "Mentoring"],
    "Finance Manager": ["Financial Modelling", "Accounting", "Leadership", "Compliance"],
    "Site Reliability Engineer": ["Kubernetes", "Containers", "Python", "AWS Cloud"],
}
mob_new = pd.DataFrame([
    {"employee_id": "EMP402", "career_interest": "Data Architecture", "target_role": "Data Architect"},
    {"employee_id": "EMP401", "career_interest": "Cloud Architecture", "target_role": "Cloud Solutions Architect"},
    {"employee_id": "EMP405", "career_interest": "ML Engineering", "target_role": "Machine Learning Engineer"},
    {"employee_id": "EMP410", "career_interest": "Site Reliability Engineering", "target_role": "Site Reliability Engineer"},
    {"employee_id": "EMP414", "career_interest": "Cybersecurity", "target_role": "Security Analyst"}])
roles = {t: None for t in sorted(set(all_emp.job_title))}
roles.update({t: TARGET_ROLE_SKILLS[t] for t in set(hr4u_employee_mobility.target_role) | set(mob_new.target_role) if t in TARGET_ROLE_SKILLS})
req_rows = []
for role, skills in sorted(roles.items()):
    if skills is None:
        fam = FAMILY_SKILLS[family(role)]
        lvl = {"L1": 1, "L2": 2, "L3": 3}.get(title_level(role), 3)
        lvl = 4 if any(k in role.lower() for k in ["lead", "manager", "director", "head", "chief", "vp"]) else lvl
        pairs = [(s, "Core", lvl) for s in fam[:4]] + [(s, "Preferred", max(lvl - 1, 1)) for s in fam[4:6]]
    else:
        pairs = [(s, "Core", 3) for s in skills]
    for s, imp, lv in pairs:
        req_rows.append({"requirement_id": f"RSR{len(req_rows) + 1:05d}", "role_name": role, "skill_name": s,
            "skill_category": SKILL_CATEGORY.get(s, "Technical"), "required_proficiency_level": LEVELS[lv],
            "required_proficiency_score": str(lv), "importance": imp, "framework": "PulseForge synthetic role framework v1",
            "last_updated_date": str(AS_OF)})
OUT["hr4u_role_skill_requirements"] = pd.DataFrame(req_rows)

# Workspace user -> manager scope (used later for Unity Catalog row filters)
mgrs = all_emp[all_emp.employee_id.isin(all_emp.manager_id)]
acc = [{"user_email": m.email, "manager_employee_id": m.employee_id, "access_role": "MANAGER", "access_scope": "DIRECT_REPORTS"} for _, m in mgrs.iterrows()]
acc += [{"user_email": "meenakshi.sundaram@pulseforge-demo.com", "manager_employee_id": "*", "access_role": "HR_ADMIN", "access_scope": "ALL_EMPLOYEES"},
        {"user_email": "arnav.anand@cgi.com", "manager_employee_id": "EMP003", "access_role": "MANAGER", "access_scope": "DIRECT_REPORTS"},
        {"user_email": "arnav.anand@cgi.com", "manager_employee_id": "EMP004", "access_role": "MANAGER", "access_scope": "DIRECT_REPORTS"}]
OUT["hr4u_manager_access"] = pd.DataFrame([{"access_id": f"ACC{i + 1:04d}", **a, "valid_from": "2026-01-01", "valid_to": "",
    "granted_by": "HR4U demo provisioning"} for i, a in enumerate(acc)])

# Reviews and goals for new employees, mobility records
rev_rows, goal_rows = [], []
strengths = sorted(set(hr4u_performance_reviews.strengths)); improvements = sorted(set(hr4u_performance_reviews.improvement_areas))
feedback = sorted(set(x for x in hr4u_performance_reviews.manager_feedback if x))
for _, e in new_emp.iterrows():
    for period, rdt in [("2025-H2", date(2026, 1, 20)), ("2026-H1", date(2026, 7, 20))]:
        if d(e.joining_date) < rdt - timedelta(days=150):
            g, c, dl = [int(rng.integers(3, 6)) for _ in range(3)]
            rev_rows.append({"review_id": f"REV1{len(rev_rows) + 1:04d}", "employee_id": e.employee_id, "reviewer_id": e.manager_id,
                "review_period": period, "review_date": str(rdt + timedelta(days=int(rng.integers(0, 20)))),
                "overall_rating": f"{(g + c + dl) / 3:.1f}", "goal_achievement_score": str(g), "collaboration_score": str(c),
                "delivery_score": str(dl), "strengths": choice(strengths), "improvement_areas": choice(improvements),
                "manager_feedback": choice(feedback), "review_status": "Completed"})
    for k in range(2):
        start = rdate(date(2026, 7, 1), date(2026, 9, 15)); pct = int(choice([100, 75, 50, 25, 0], p=[0.3, 0.25, 0.25, 0.15, 0.05]))
        goal_rows.append({"goal_id": f"GOAL1{len(goal_rows) + 1:04d}", "employee_id": e.employee_id,
            "goal_title": choice(["Ship quarterly roadmap items", "Complete a cloud certification", "Improve ticket resolution time", "Mentor a junior colleague", "Automate a manual process"]),
            "goal_description": "Synthetic demo goal (batch01)", "goal_category": choice(["Delivery", "Technical", "Leadership"]),
            "start_date": str(start), "target_date": str(start + timedelta(days=150)), "completion_percentage": str(pct),
            "goal_status": "Completed" if pct == 100 else ("Not Started" if pct == 0 else "In Progress"), "manager_id": e.manager_id,
            "last_updated_date": str(AS_OF)})
OUT["hr4u_performance_reviews"] = pd.DataFrame(rev_rows)[hr4u_performance_reviews.columns]
OUT["hr4u_employee_goals"] = pd.DataFrame(goal_rows)[hr4u_employee_goals.columns]
mob_rows = []
for i, m in mob_new.iterrows():
    e = all_emp[all_emp.employee_id == m.employee_id].iloc[0]
    mob_rows.append({"mobility_id": f"MOB1{i + 1:03d}", "employee_id": e.employee_id, "current_department": e.department_name,
        "previous_department": e.department_name, "current_role": e.job_title, "previous_role": e.job_title, "mobility_type": "Internal Transfer",
        "effective_date": str(rdate(date(2027, 1, 1), date(2027, 3, 31))), "career_interest": m.career_interest, "target_role": m.target_role,
        "mobility_status": "Proposed"})
OUT["hr4u_employee_mobility"] = pd.DataFrame(mob_rows)[hr4u_employee_mobility.columns]
print({k: len(v) for k, v in OUT.items()})

# COMMAND ----------

# DBTITLE 1,Jira - new issues, Blocked status, timed worklogs
proj = (jira_issues.assign(k=jira_issues.issue_key.str.extract(r"^([A-Z]+)-")[0], n=jira_issues.issue_key.str.extract(r"-(\d+)$")[0].astype(int))
        .groupby(["project_id", "project_name", "k"]).n.max().reset_index())
next_key = {r.project_id: r.n + 1 for r in proj.itertuples()}
key_of = {r.project_id: r.k for r in proj.itertuples()}
sprints = jira_sprints.assign(s=jira_sprints.start_date.map(d), e=jira_sprints.end_date.map(d))
PROJECTS = {"data": ["1002", "1001", "1003"], "software": ["1004", "1005", "1001", "1003"]}
pname = dict(zip(proj.project_id, proj.project_name))
devs = active[active.family.isin(["data", "software"])]
overloaded = {"EMP402", "EMP117", "EMP406"}           # Kavitha Nair, Lakshmi Suresh, Ganesh Reddy
VERBS = ["Implement", "Refactor", "Fix", "Optimise", "Add tests for", "Migrate", "Document", "Harden"]
OBJS = ["ingestion job", "customer search API", "login flow", "Delta merge logic", "push notifications", "CI pipeline",
        "dashboard filters", "payment retry", "schema validation", "Kubernetes deployment", "data quality checks", "cache layer"]
labels_pool = sorted(set(x for x in jira_issues.labels if x))

def sprint_for(pid, day):
    s = sprints[sprints.project_id == pid]
    hit = s[(s.s <= day) & (s.e >= day)]
    return (hit if len(hit) else s[s.s <= day].tail(1) if len(s[s.s <= day]) else s.head(1)).iloc[0]

issues, wls = [], []
next_issue, next_wl = 60001, 960001
for _, e in devs.iterrows():
    my_projects = list(rng.choice(PROJECTS[e.family], size=int(rng.integers(1, 4)), replace=False))
    n = int(rng.poisson(30 if e.employee_id in overloaded else 14))
    for _ in range(n):
        pid = choice(my_projects)
        created = rdate(max(date(2026, 6, 1), d(e.joining_date)), AS_OF)
        age = (AS_OF - created).days
        if e.employee_id in overloaded:
            status = choice(["Done", "In Progress", "To Do", "Blocked"], p=[0.45, 0.25, 0.15, 0.15])
        elif age <= 14:
            status = choice(["To Do", "In Progress", "Blocked", "Done"], p=[0.4, 0.4, 0.1, 0.1])
        else:
            status = choice(["Done", "In Progress", "To Do", "Blocked"], p=[0.78, 0.1, 0.05, 0.07])
        sp = sprint_for(pid, created)
        itype = choice(["Story", "Task", "Bug", "Epic"], p=[0.4, 0.3, 0.25, 0.05])
        resolved = min(created + timedelta(days=int(rng.integers(1, 16))), AS_OF) if status == "Done" else None
        updated = resolved or rdate(created, AS_OF)
        obj = choice(OBJS); verb = choice(VERBS)
        key = f"{key_of[pid]}-{next_key[pid]}"; next_key[pid] += 1
        issue = {"issue_id": str(next_issue), "issue_key": key, "project_id": pid, "project_name": pname[pid],
            "summary": f"{verb} {obj}", "description": f"Synthetic demo description (batch01): {verb.lower()} {obj}.",
            "issue_type": itype, "priority": choice(["Medium", "High", "Low", "Highest"], p=[0.45, 0.27, 0.2, 0.08]),
            "status": status, "assignee_id": e.employee_id, "assignee_name": e.employee_name,
            "reporter_id": choice(list(devs.employee_id) + [e.manager_id]), "created_date": str(created), "updated_date": str(updated),
            "due_date": str(sp.e), "resolved_date": str(resolved) if resolved else "",
            "story_points": str(choice([13, 21]) if itype == "Epic" else choice([1, 2, 3, 5, 8, 13], p=[0.15, 0.2, 0.25, 0.22, 0.13, 0.05])),
            "sprint_id": sp.sprint_id, "labels": choice(labels_pool),
            "resolution": ("Fixed" if itype == "Bug" else "Done") if status == "Done" else "Unresolved"}
        issues.append(issue); next_issue += 1
        if status == "To Do":
            continue
        end = resolved or AS_OF
        after_hours_p = 0.35 if e.employee_id in overloaded else 0.08
        for _ in range(int(rng.integers(1, 5))):
            author = e if rng.random() < 0.85 else devs.sample(1, random_state=int(rng.integers(10**9))).iloc[0]
            wday = rdate(created, end)
            start = rts(wday, 19, 24) if rng.random() < after_hours_p else rts(wday, 9, 18)
            wls.append({"worklog_id": str(next_wl), "issue_id": issue["issue_id"], "employee_id": author.employee_id,
                "employee_name": author.employee_name, "work_date": str(wday),
                "time_spent_hours": str(choice([0.5, 1.0, 1.5, 2.0, 3.0, 4.0, 6.0, 8.0], p=[0.1, 0.15, 0.15, 0.2, 0.15, 0.12, 0.08, 0.05])),
                "work_description": f"Worked on {key} - {issue['summary'].lower()}", "created_date": str(wday),
                "work_start_time": fmt_ts(start)})
            next_wl += 1

# Updates to existing open issues: some become Blocked, some get completed (Silver MERGE updates these keys)
open_old = jira_issues[jira_issues.status != "Done"].sample(65, random_state=7)
upd_issues = []
for i, (_, r) in enumerate(open_old.iterrows()):
    r = r.copy()
    if i < 25:
        r["status"], r["updated_date"] = "Blocked", "2026-11-16"
    else:
        res = rdate(max(d(r.created_date), date(2026, 10, 20)), AS_OF)
        r["status"], r["resolved_date"], r["updated_date"], r["resolution"] = "Done", str(res), str(res), "Done"
    upd_issues.append(r)
OUT["jira_issues"] = pd.concat([pd.DataFrame(upd_issues), pd.DataFrame(issues)], ignore_index=True)[jira_issues.columns]
OUT["jira_worklogs"] = pd.DataFrame(wls)[list(jira_worklogs.columns) + ["work_start_time"]]
print("jira issues:", len(OUT["jira_issues"]), OUT["jira_issues"].status.value_counts().to_dict(), "| worklogs:", len(OUT["jira_worklogs"]))

# COMMAND ----------

# DBTITLE 1,ServiceNow - incidents, requests and tasks
combos = servicenow_incidents[["assignment_group", "category", "subcategory", "short_description"]].drop_duplicates().reset_index(drop=True)
group_staff = {g: sorted(set(x for x in servicenow_incidents.loc[servicenow_incidents.assignment_group == g, "assigned_to_id"] if x)) for g in combos.assignment_group.unique()}
TITLE_GROUP = {"Service Desk Analyst": "Service Desk", "Senior Service Desk Analyst": "Service Desk", "Desktop Support Technician": "Desktop Support",
               "Application Support Analyst": "Application Support", "Network Engineer": "Network Operations", "Senior Network Engineer": "Network Operations",
               "Database Administrator": "Database Support", "Senior Database Administrator": "Database Support", "Senior IAM Specialist": "Identity & Access Mgmt"}
for _, e in new_emp[new_emp.employment_status == "Active"].iterrows():
    if e.job_title in TITLE_GROUP:
        group_staff[TITLE_GROUP[e.job_title]].append(e.employee_id)
busy_support = next(x for x in group_staff["Application Support"])  # gets extra volume
name_of = dict(zip(all_emp.employee_id, all_emp.employee_name))
pr_codes = servicenow_incidents.groupby("priority")[["urgency", "impact"]].agg(lambda s: s.mode()[0]).to_dict("index")
SLA_H = {"Critical": 4, "High": 8, "Medium": 24, "Low": 72}
MEAN_H = {"Critical": 3, "High": 7, "Medium": 18, "Low": 40}
AS_OF_END = datetime(AS_OF.year, AS_OF.month, AS_OF.day, 23, 59, 0)

inc = []
for i in range(550):
    c = combos.iloc[int(rng.integers(len(combos)))]
    staff = group_staff[c.assignment_group]
    if c.assignment_group == "Application Support" and rng.random() < 0.35:
        assignee = busy_support
    else:
        assignee = choice(staff) if staff else ""
    caller = choice([x for x in all_emp.employee_id if x != assignee])
    pr = choice(["Low", "Medium", "High", "Critical"], p=[0.45, 0.35, 0.15, 0.05])
    opened = rts(rdate(date(2026, 5, 20), AS_OF), 0, 24) if rng.random() < 0.2 else rts(rdate(date(2026, 5, 20), AS_OF))
    hours = float(rng.lognormal(np.log(MEAN_H[pr]), 0.7))
    resolved = opened + timedelta(hours=hours)
    if (AS_OF_END - opened).days < 3 and rng.random() < 0.6 or resolved > AS_OF_END:
        state, resolved, closed = choice(["New", "In Progress"]), None, None
    else:
        state = choice(["Closed", "Resolved"], p=[0.8, 0.2])
        closed = min(resolved + timedelta(hours=float(rng.uniform(12, 72))), AS_OF_END) if state == "Closed" else None
    elapsed = ((resolved or AS_OF_END) - opened).total_seconds() / 3600
    sla = "Met" if elapsed <= SLA_H[pr] else "Breached"
    if resolved is None and elapsed <= SLA_H[pr]:
        sla = ""
    inc.append({"incident_id": f"INC2001{i + 1:04d}", "employee_id": caller, "employee_name": name_of[caller],
        "assigned_to_id": assignee, "assigned_to_name": name_of.get(assignee, ""), "assignment_group": c.assignment_group,
        "category": c.category, "subcategory": c.subcategory, "short_description": c.short_description,
        "description": f"Synthetic demo incident (batch01): user {name_of[caller]} reports '{c.short_description.lower()}'.",
        "priority": pr, "urgency": pr_codes[pr]["urgency"], "impact": pr_codes[pr]["impact"], "state": state,
        "opened_date": fmt_ts(opened), "resolved_date": fmt_ts(resolved) if resolved else "", "closed_date": fmt_ts(closed) if closed else "",
        "resolution_time_hours": f"{hours:.2f}" if resolved else "", "reopen_count": str(choice([0, 1, 2], p=[0.9, 0.08, 0.02])),
        "sla_status": sla, "satisfaction_score": f"{choice([1, 2, 3, 4, 5], p=[0.05, 0.1, 0.25, 0.35, 0.25])}.0" if state == "Closed" and rng.random() < 0.6 else ""})
OUT["servicenow_incidents"] = pd.DataFrame(inc)[servicenow_incidents.columns]

rcombos = servicenow_requests[["request_type", "request_category", "requested_item", "assigned_group"]].drop_duplicates().reset_index(drop=True)
req, tasks = [], []
for i in range(320):
    c = rcombos.iloc[int(rng.integers(len(rcombos)))]
    staff = group_staff.get(c.assigned_group) or group_staff["Service Desk"]
    assignee = choice(staff)
    requester = choice(list(all_emp.employee_id))
    rdt = rts(rdate(date(2026, 5, 20), AS_OF))
    hours = float(rng.lognormal(np.log(30), 0.6))
    done = rdt + timedelta(hours=hours)
    if done > AS_OF_END:
        status, approval, done = choice(["Work in Progress", "Pending Approval"], p=[0.8, 0.2]), "Approved", None
        approval = "Pending" if status == "Pending Approval" else "Approved"
    else:
        status = choice(["Closed Complete", "Closed Rejected", "Closed Incomplete"], p=[0.86, 0.08, 0.06])
        approval = "Rejected" if status == "Closed Rejected" else "Approved"
    rid = f"RITM2002{i + 1:04d}"
    req.append({"request_id": rid, "employee_id": requester, "request_type": c.request_type, "request_category": c.request_category,
        "requested_item": c.requested_item, "assigned_group": c.assigned_group, "assigned_to_id": assignee, "request_status": status,
        "request_date": fmt_ts(rdt), "approval_status": approval, "completion_date": fmt_ts(done) if done else "",
        "fulfillment_time_hours": f"{hours:.2f}" if done else ""})
    steps = ["Approval"] + list(rng.choice(["Provisioning", "Configuration", "Delivery", "Verification", "Procurement"], size=int(rng.integers(1, 3)), replace=False))
    t0 = rdt
    for k, ttype in enumerate(steps):
        created = t0 + timedelta(minutes=int(rng.integers(10, 240)))
        finished = created + timedelta(hours=float(rng.uniform(0.5, max(hours / len(steps), 1))))
        closed_req = status.startswith("Closed")
        tstatus = ("Closed Complete" if status != "Closed Incomplete" else "Closed Incomplete") if closed_req else ("Work in Progress" if k == len(steps) - 1 else "Closed Complete")
        if not closed_req and finished > AS_OF_END:
            tstatus = "Open"
        tasks.append({"task_id": f"SCTASK3002{len(tasks) + 1:05d}", "parent_request_id": rid,
            "assigned_to_id": choice(staff) if ttype == "Approval" else assignee, "employee_id": requester, "task_type": ttype,
            "task_status": tstatus, "priority": choice(["Medium", "High", "Low", "Critical"], p=[0.55, 0.2, 0.2, 0.05]),
            "created_date": fmt_ts(created), "completed_date": fmt_ts(min(finished, AS_OF_END)) if tstatus.startswith("Closed") else "",
            "work_notes": f"Synthetic demo task (batch01): {ttype.lower()} for {c.requested_item}"})
        t0 = created
OUT["servicenow_requests"] = pd.DataFrame(req)[servicenow_requests.columns]
OUT["servicenow_tasks"] = pd.DataFrame(tasks)[servicenow_tasks.columns]
print("incidents:", len(inc), "requests:", len(req), "tasks:", len(tasks))

# COMMAND ----------

# DBTITLE 1,LMS - learning activity and certifications
courses = lms_courses[lms_courses.course_status == "Active"].reset_index(drop=True)
have = set(zip(lms_learning_activity.employee_id, lms_learning_activity.course_id))
la_rows = []
for _, e in all_emp.iterrows():
    fam_sk = set(FAMILY_SKILLS[e.family])
    w = np.array([3.0 if s in fam_sk else (2.0 if m == "Mandatory" else 1.0) for s, m in zip(courses.skill_name, courses.mandatory_flag)])
    n = int(rng.poisson(5 if e.employee_id in set(new_emp.employee_id) else 3))
    for ci in rng.choice(len(courses), size=min(n, len(courses)), replace=False, p=w / w.sum()):
        c = courses.iloc[int(ci)]
        if (e.employee_id, c.course_id) in have:
            continue
        have.add((e.employee_id, c.course_id))
        enr = rdate(max(date(2025, 12, 1), d(e.joining_date)), AS_OF)
        recent = (AS_OF - enr).days < 45
        status = choice(["Enrolled", "In Progress", "Completed"], p=[0.4, 0.45, 0.15] if recent else [0.12, 0.18, 0.7])
        dur = float(c.course_duration_hours)
        start = min(enr + timedelta(days=int(rng.integers(0, 10))), AS_OF) if status != "Enrolled" else None
        comp = start + timedelta(days=int(rng.integers(1, 31))) if status == "Completed" else None
        if comp and comp > AS_OF:
            status, comp = "In Progress", None
        prog = 100 if status == "Completed" else (int(rng.integers(10, 91)) if status == "In Progress" else 0)
        hrs = dur * rng.uniform(0.8, 1.4) if status == "Completed" else dur * prog / 100 * rng.uniform(0.8, 1.2)
        score = int(np.clip(rng.normal(78, 11), 35, 100)) if status == "Completed" else None
        la_rows.append({"learning_activity_id": f"LA1{len(la_rows) + 1:05d}", "employee_id": e.employee_id, "course_id": c.course_id,
            "enrollment_date": str(enr), "start_date": str(start) if start else "", "completion_date": str(comp) if comp else "",
            "learning_status": status, "progress_percentage": str(prog), "learning_hours": f"{hrs:.1f}",
            "assessment_score": str(score) if score is not None else "",
            "pass_status": ("Passed" if score >= 60 else "Failed") if score is not None else "Pending",
            "last_activity_date": str(comp or (rdate(start, AS_OF) if start else enr))})
OUT["lms_learning_activity"] = pd.DataFrame(la_rows)[lms_learning_activity.columns]

CERTS = {  # name -> (provider, skill_category, validity years)
    "Databricks Certified Data Engineer Associate": ("Databricks", "Data Engineering", 2),
    "Databricks Certified Data Engineer Professional": ("Databricks", "Data Engineering", 2),
    "Databricks Certified Machine Learning Associate": ("Databricks", "Machine Learning", 2),
    "Microsoft Certified: Azure Data Engineer Associate": ("Microsoft", "Cloud", 1),
    "Microsoft Certified: Azure Fundamentals": ("Microsoft", "Cloud", 3),
    "Microsoft Certified: Azure Administrator Associate": ("Microsoft", "Cloud", 1),
    "AWS Certified Data Engineer - Associate": ("Amazon Web Services", "Cloud", 3),
    "AWS Certified Solutions Architect - Associate": ("Amazon Web Services", "Cloud", 3),
    "Certified Kubernetes Application Developer": ("CNCF", "Cloud Native", 2),
    "Professional Scrum Master I": ("Scrum.org", "Agile", 5),
    "ITIL 4 Foundation": ("AXELOS", "IT Service Management", 3),
    "ServiceNow Certified System Administrator": ("ServiceNow", "ServiceNow", 2),
    "CompTIA Security+": ("CompTIA", "Security", 3), "Cisco CCNA": ("Cisco", "Networking", 3),
    "Microsoft Certified: Identity and Access Administrator": ("Microsoft", "Security", 1),
    "CIPD Level 5 Associate Diploma": ("CIPD", "Human Resources", 5), "ACCA Professional": ("ACCA", "Accounting", 5)}
FAMILY_CERTS = {"data": ["Databricks Certified Data Engineer Associate", "Databricks Certified Data Engineer Professional", "Microsoft Certified: Azure Data Engineer Associate", "AWS Certified Data Engineer - Associate", "Databricks Certified Machine Learning Associate", "Microsoft Certified: Azure Fundamentals"],
    "software": ["AWS Certified Solutions Architect - Associate", "Certified Kubernetes Application Developer", "Microsoft Certified: Azure Fundamentals", "Professional Scrum Master I", "Microsoft Certified: Azure Administrator Associate"],
    "support": ["ITIL 4 Foundation", "ServiceNow Certified System Administrator", "Microsoft Certified: Azure Fundamentals"], "network": ["Cisco CCNA", "CompTIA Security+", "Microsoft Certified: Azure Administrator Associate"],
    "dba": ["Microsoft Certified: Azure Fundamentals", "Microsoft Certified: Azure Data Engineer Associate"], "iam": ["Microsoft Certified: Identity and Access Administrator", "CompTIA Security+"],
    "hr": ["CIPD Level 5 Associate Diploma"], "finance": ["ACCA Professional"], "leadership": ["Professional Scrum Master I", "Microsoft Certified: Azure Fundamentals"]}
held = set(zip(lms_certifications.employee_id, lms_certifications.certification_name))
ct_rows = []
for _, e in all_emp.iterrows():
    p_cert = 0.75 if e.family in ("data", "software") else 0.45
    for name in rng.choice(FAMILY_CERTS[e.family], size=min(2, len(FAMILY_CERTS[e.family])), replace=False):
        if rng.random() > p_cert or (e.employee_id, name) in held:
            continue
        held.add((e.employee_id, name)); prov, cat, yrs = CERTS[name]
        status = choice(["Active", "In Progress", "Expired"], p=[0.7, 0.2, 0.1])
        if status == "Active":
            iss = rdate(max(date(2025, 1, 1), d(e.joining_date)), AS_OF); exp = date(iss.year + yrs, iss.month, min(iss.day, 28))
        elif status == "Expired":
            iss = rdate(date(2021, 1, 1), date(2023, 6, 30)); exp = date(iss.year + yrs, iss.month, min(iss.day, 28))
            if exp >= AS_OF: status = "Active"
        else:
            iss = exp = None
        ct_rows.append({"certification_id": f"CERT1{len(ct_rows) + 1:04d}", "employee_id": e.employee_id, "certification_name": name,
            "certification_provider": prov, "skill_category": cat, "issue_date": str(iss) if iss else "", "expiry_date": str(exp) if exp else "",
            "certification_status": status, "credential_id": f"{prov[:1]}-{int(rng.integers(100000, 999999))}" if iss else "",
            "verification_status": ("Verified" if rng.random() < 0.8 else "Pending") if iss else "Pending"})
OUT["lms_certifications"] = pd.DataFrame(ct_rows)[lms_certifications.columns]
print("learning:", len(la_rows), OUT["lms_learning_activity"].learning_status.value_counts().to_dict(),
      "| certifications:", len(ct_rows), OUT["lms_certifications"].certification_status.value_counts().to_dict())

# COMMAND ----------

# DBTITLE 1,Validate referential integrity and write synthetic files
ids = set(all_emp.employee_id)
checks = {
    "employee refs": [(k, c) for k, df in OUT.items() for c in df.columns
                      if c in ("employee_id", "assignee_id", "reporter_id", "assigned_to_id", "manager_id", "reviewer_id")
                      and not set(x for x in df[c] if x).issubset(ids)],
    "manager_access refs": not set(x for x in OUT["hr4u_manager_access"].manager_employee_id if x != "*").issubset(ids),
    "sprint refs": not set(OUT["jira_issues"].sprint_id).issubset(set(jira_sprints.sprint_id)),
    "worklog issue refs": not set(OUT["jira_worklogs"].issue_id).issubset(set(OUT["jira_issues"].issue_id) | set(jira_issues.issue_id)),
    "task request refs": not set(OUT["servicenow_tasks"].parent_request_id).issubset(set(OUT["servicenow_requests"].request_id)),
    "course refs": not set(OUT["lms_learning_activity"].course_id).issubset(set(lms_courses.course_id)),
    "new ids collide with originals": any(set(OUT[k][c]) & set(globals()[k][c]) for k, c in [
        ("servicenow_incidents", "incident_id"), ("servicenow_requests", "request_id"), ("servicenow_tasks", "task_id"),
        ("lms_learning_activity", "learning_activity_id"), ("lms_certifications", "certification_id"), ("jira_worklogs", "worklog_id"),
        ("hr4u_performance_reviews", "review_id"), ("hr4u_employee_goals", "goal_id"), ("hr4u_employee_mobility", "mobility_id")]),
    "future dated activity": any(x > str(AS_OF) + " 23:59:59" for k, c in [("jira_issues", "resolved_date"), ("jira_worklogs", "work_date"),
        ("servicenow_incidents", "resolved_date"), ("lms_learning_activity", "completion_date")] for x in OUT[k][c] if x),
}
bad = {k: v for k, v in checks.items() if v}
assert not bad, f"Synthetic data validation failed: {bad}"

def write_if_changed(df, path):
    """Write the CSV only when its content changed, so re-running does not touch the file (no Bronze re-ingest)."""
    text = df.to_csv(index=False)
    try:
        with open(path) as f:
            if f.read() == text:
                return "unchanged"
    except FileNotFoundError:
        pass
    with open(path, "w") as f:
        f.write(text)
    return "written"

written = []
for name, df in OUT.items():
    path = f"{SRC}/{name}_{BATCH}.csv"
    written.append((name, f"{name}_{BATCH}.csv", len(df), write_if_changed(df, path)))
with open(f"{SRC}/README_{BATCH}.txt", "w") as f:
    f.write(f"PulseForge SYNTHETIC demo data, {BATCH}, generated by 05_PulseForge_Synthetic_Data_Generator (seed 20261118, as of {AS_OF}).\n"
            "All *_synthetic_batch01.csv files are synthetic. Original source CSVs are unchanged.\n")
display(pd.DataFrame(written, columns=["source", "file", "rows", "action"]))

# COMMAND ----------

# DBTITLE 1,Batch 02 overview
# MAGIC %md
# MAGIC ## Batch 02 - scale-up for the AI/BI dashboards (SYNTHETIC)
# MAGIC Adds data on top of the originals and batch 01, using **new ID ranges only**, so nothing already loaded gets overwritten or orphaned. Files are named `<source>_synthetic_batch02.csv` and loaded by the same pipeline with no code changes.
# MAGIC
# MAGIC * **People**: 10 new managers (6 Engineering Managers, 4 IT Support Managers), giving 18 managers in total, plus 210 new employees across all departments (about 300 in total), including recent hires, some on leave and some inactive.
# MAGIC * **History**: activity from June 2025 to the batch date, so the 30/90/180/365-day windows and monthly trends are populated. Activity varies by month and grows over time.
# MAGIC * **Jira**: 2 new projects (Cloud Migration, Analytics Platform), historical sprints for the existing projects, and thousands of issues and timed worklogs. A few employees are deliberately overloaded.
# MAGIC * **ServiceNow, LMS, HR4U**: incidents, requests and tasks at a growing monthly volume; enrollments and certifications (including 2025 history for existing employees); reviews, goals, mobility proposals, skill profiles and manager access for the new people.

# COMMAND ----------

# DBTITLE 1,Batch 02 setup and new employees
BATCH2 = "synthetic_batch02"
rng = np.random.default_rng(20261119)          # separate seed for batch 02 (batch 01 above stays identical)
H_START = date(2025, 6, 1)
OUT2 = {}
SEASON = {1: 1.0, 2: 1.05, 3: 1.15, 4: 1.0, 5: 0.95, 6: 0.9, 7: 1.0, 8: 1.05, 9: 1.15, 10: 1.1, 11: 1.05, 12: 0.75}

def months(a, b):
    m = date(a.year, a.month, 1)
    while m <= b:
        nxt = date(m.year + (m.month == 12), m.month % 12 + 1, 1)
        yield max(m, a), min(nxt - timedelta(days=1), b)
        m = nxt

FIRST2 = ["Aditya", "Akshay", "Amit", "Ankita", "Aparna", "Ashwin", "Chetan", "Darshan", "Esha", "Farhan", "Gauri", "Gautam",
          "Hemant", "Isha", "Jayant", "Kunal", "Lata", "Madhuri", "Mohit", "Namrata", "Nisha", "Omkar", "Pallavi", "Pranav",
          "Rahul", "Rekha", "Sachin", "Sakshi", "Shalini", "Shiv", "Sneha", "Suraj", "Tanvi", "Uday", "Vaishali", "Vinay",
          "Yash", "Zoya", "Abhishek", "Charu", "Dinesh", "Geeta", "Irfan", "Jyoti"]
LAST2 = ["Agarwal", "Bhat", "Chatterjee", "Das", "Dutta", "Fernandes", "Ghosh", "Hegde", "Jain", "Kulkarni", "Mishra", "Mukherjee",
         "Naidu", "Pandey", "Prasad", "Rajan", "Saxena", "Sen", "Sinha", "Srinivasan", "Thomas", "Tiwari", "Varghese", "Yadav", "Kamath"]
used_names = set(all_emp.employee_name)
def new_name():
    while True:
        n = f"{choice(FIRST2)} {choice(LAST2)}"
        if n not in used_names:
            used_names.add(n); return n

emp_by_id = {r.employee_id: r for r in all_emp.itertuples()}
dept_row = {r.department_id: r for r in all_emp[all_emp.manager_id.isin(["EMP003", "EMP004", "EMP006", "EMP007", "EMP008"])].drop_duplicates("department_id").itertuples()}
TEAM_TITLES = {dep: sorted(set(all_emp.loc[all_emp.manager_id == m, "job_title"])) for dep, m in
               [("D200", "EMP003"), ("D210", "EMP004"), ("D300", "EMP006"), ("D400", "EMP007"), ("D500", "EMP008")]}

def make_emp(eid, name, dep, title, mgr, joined, status):
    p, m = dept_row[dep], emp_by_id[mgr]
    loc = choice(locs)
    return {"employee_id": eid, "employee_name": name, "email": name.lower().replace(" ", ".") + f".{eid.lower()}@pulseforge-demo.com",
        "department_id": dep, "department_name": p.department_name, "business_unit": p.business_unit, "job_title": title,
        "job_level": "L5" if "Manager" in title else title_level(title), "manager_id": mgr, "manager_name": m.employee_name,
        "location": loc[0], "country": loc[1], "employment_type": "Contract" if rng.random() < 0.1 else "Permanent",
        "joining_date": str(joined), "employment_status": status,
        "experience_years": f"{(AS_OF - joined).days / 365 + rng.uniform(0, 8):.1f}", "cost_center": p.cost_center,
        "last_updated_date": str(max(joined, date(2026, 10, 15)))}

rows, next_emp = [], 501
new_mgrs = {"D200": [], "D210": [], "D300": []}
for dep, title, boss, n in [("D200", "Engineering Manager", "EMP002", 3), ("D210", "Engineering Manager", "EMP002", 3), ("D300", "IT Support Manager", "EMP005", 4)]:
    for _ in range(n):
        eid = f"EMP{next_emp}"; next_emp += 1
        r = make_emp(eid, new_name(), dep, title, boss, rdate(date(2014, 1, 1), date(2022, 12, 31)), "Active")
        rows.append(r); new_mgrs[dep].append(eid); emp_by_id[eid] = pd.Series(r)
for dep, base_mgr, n in [("D200", "EMP003", 60), ("D210", "EMP004", 50), ("D300", "EMP006", 60), ("D400", "EMP007", 15), ("D500", "EMP008", 25)]:
    pool = [base_mgr] + new_mgrs.get(dep, [])
    for _ in range(n):
        eid = f"EMP{next_emp}"; next_emp += 1
        joined = rdate(date(2025, 6, 1), date(2026, 9, 30)) if rng.random() < 0.3 else rdate(date(2017, 1, 1), date(2025, 5, 31))
        status = choice(["Active", "On Leave", "Inactive"], p=[0.94, 0.03, 0.03])
        rows.append(make_emp(eid, new_name(), dep, choice(TEAM_TITLES[dep]), choice(pool), joined, status))
new2 = pd.DataFrame(rows)
assert not set(new2.employee_id) & set(all_emp.employee_id)
OUT2["hr4u_employees"] = new2[emp0.columns]
all2 = pd.concat([all_emp.drop(columns="family"), new2[emp0.columns]], ignore_index=True)
all2["family"] = all2.job_title.map(family)
prior_ids = set(all_emp.employee_id)
print(f"batch02 employees: {len(new2)} (managers {sum(len(v) for v in new_mgrs.values())}); total employees {len(all2)}, managers {all2.manager_id.nunique()}")

# COMMAND ----------

# DBTITLE 1,Batch 02 HR4U - skills, access, reviews, goals, mobility
sk2 = []
for _, e in new2.iterrows():
    fam = FAMILY_SKILLS[family(e.job_title)]
    picked = [s for s in fam[:4] if rng.random() < 0.85] + list(rng.choice(fam[4:] or fam, size=min(2, len(fam[4:] or fam)), replace=False))
    if "Manager" in e.job_title or e.job_level == "L4":
        picked += ["Leadership", "Mentoring", "Project Management"]
    base = {"L1": 1, "L2": 2, "L3": 3}.get(e.job_level, 3)
    for s in dict.fromkeys(picked):
        score = int(np.clip(base + rng.choice([-1, 0, 0, 1]), 1, 4))
        sk2.append({"employee_skill_id": f"ESK2{len(sk2) + 1:05d}", "employee_id": e.employee_id, "skill_name": s,
            "skill_category": SKILL_CATEGORY.get(s, "Technical"), "proficiency_level": LEVELS[score], "proficiency_score": str(score),
            "experience_years": f"{min(float(e.experience_years), rng.uniform(0.5, 10)):.1f}",
            "last_assessed_date": str(rdate(max(date(2025, 6, 1), d(e.joining_date)), AS_OF)),
            "assessment_source": choice(["Manager", "Self", "Manager"]), "last_updated_date": str(AS_OF)})
OUT2["hr4u_employee_skills"] = pd.DataFrame(sk2)

missing_roles = set(all2.job_title) - set(OUT["hr4u_role_skill_requirements"].role_name)
assert not missing_roles, f"add role requirements for {missing_roles}"

mgr_rows = new2[new2.job_title.str.contains("Manager")]
OUT2["hr4u_manager_access"] = pd.DataFrame([{"access_id": f"ACC1{i + 1:03d}", "user_email": m.email, "manager_employee_id": m.employee_id,
    "access_role": "MANAGER", "access_scope": "DIRECT_REPORTS", "valid_from": "2026-01-01", "valid_to": "",
    "granted_by": "HR4U demo provisioning"} for i, m in enumerate(mgr_rows.itertuples())])

rev2, goal2 = [], []
for _, e in new2.iterrows():
    for period, rdt in [("2025-H1", date(2025, 7, 20)), ("2025-H2", date(2026, 1, 20)), ("2026-H1", date(2026, 7, 20))]:
        if d(e.joining_date) < rdt - timedelta(days=150) and e.employment_status != "Inactive":
            g, c, dl = [int(rng.integers(2, 6)) for _ in range(3)]
            rev2.append({"review_id": f"REV2{len(rev2) + 1:05d}", "employee_id": e.employee_id, "reviewer_id": e.manager_id,
                "review_period": period, "review_date": str(rdt + timedelta(days=int(rng.integers(0, 20)))),
                "overall_rating": f"{(g + c + dl) / 3:.1f}", "goal_achievement_score": str(g), "collaboration_score": str(c),
                "delivery_score": str(dl), "strengths": choice(strengths), "improvement_areas": choice(improvements),
                "manager_feedback": choice(feedback), "review_status": choice(["Completed", "Completed", "Completed", "Submitted"])})
    for _ in range(2):
        start = rdate(max(date(2026, 1, 5), d(e.joining_date)), date(2026, 9, 30)); pct = int(choice([100, 75, 50, 25, 0], p=[0.3, 0.25, 0.25, 0.15, 0.05]))
        goal2.append({"goal_id": f"GOAL2{len(goal2) + 1:05d}", "employee_id": e.employee_id,
            "goal_title": choice(["Ship quarterly roadmap items", "Complete a cloud certification", "Improve ticket resolution time", "Mentor a junior colleague", "Automate a manual process", "Reduce production incidents"]),
            "goal_description": "Synthetic demo goal (batch02)", "goal_category": choice(["Delivery", "Technical", "Leadership"]),
            "start_date": str(start), "target_date": str(start + timedelta(days=150)), "completion_percentage": str(pct),
            "goal_status": "Completed" if pct == 100 else ("Not Started" if pct == 0 else "In Progress"), "manager_id": e.manager_id,
            "last_updated_date": str(AS_OF)})
OUT2["hr4u_performance_reviews"] = pd.DataFrame(rev2)[hr4u_performance_reviews.columns]
OUT2["hr4u_employee_goals"] = pd.DataFrame(goal2)[hr4u_employee_goals.columns]

TARGETS = {"data": [("Data Architecture", "Data Architect"), ("ML Engineering", "Machine Learning Engineer"), ("Data Science", "Data Scientist")],
           "software": [("Cloud Architecture", "Cloud Solutions Architect"), ("Site Reliability Engineering", "Site Reliability Engineer"), ("Engineering Management", "Engineering Manager")],
           "support": [("Cloud Operations", "Cloud Operations Engineer"), ("Cybersecurity", "Security Analyst")], "network": [("Cybersecurity", "Security Analyst")],
           "dba": [("Data Architecture", "Data Architect")], "iam": [("Cybersecurity", "Security Analyst")],
           "hr": [("HR Leadership", "HR Manager"), ("Talent Analytics", "People Analytics Lead")], "finance": [("Finance Leadership", "Finance Manager"), ("Business Analytics", "Business Analyst")]}
mob2 = []
cand = all2[(all2.employment_status == "Active") & (all2.family != "leadership") & ~all2.employee_id.isin(hr4u_employee_mobility.employee_id) & ~all2.employee_id.isin(OUT["hr4u_employee_mobility"].employee_id)]
for e in cand.sample(30, random_state=11).itertuples():
    interest, target = choice(TARGETS[e.family])
    mob2.append({"mobility_id": f"MOB2{len(mob2) + 1:03d}", "employee_id": e.employee_id, "current_department": e.department_name,
        "previous_department": e.department_name, "current_role": e.job_title, "previous_role": e.job_title, "mobility_type": "Internal Transfer",
        "effective_date": str(rdate(date(2026, 12, 15), date(2027, 4, 30))), "career_interest": interest, "target_role": target,
        "mobility_status": choice(["Proposed", "Approved"], p=[0.7, 0.3])})
OUT2["hr4u_employee_mobility"] = pd.DataFrame(mob2)[hr4u_employee_mobility.columns]
print({k: len(v) for k, v in OUT2.items()})

# COMMAND ----------

# DBTITLE 1,Batch 02 Jira - projects, sprints, issues, worklogs
spr_prefix = {r.project_id: r.sprint_id.split("-SPR-")[0] for r in jira_sprints.itertuples()}
first_start = jira_sprints.assign(s=jira_sprints.start_date.map(d)).groupby("project_id").s.min()
spr_rows = []
def add_sprint(sid, name, pid, st):
    en = st + timedelta(days=13)
    status = "Completed" if en < AS_OF else "Active"
    committed = int(rng.integers(20, 61))
    spr_rows.append({"sprint_id": sid, "sprint_name": name, "project_id": pid, "start_date": str(st), "end_date": str(en),
        "sprint_status": status, "committed_story_points": str(committed),
        "completed_story_points": str(int(committed * rng.uniform(0.6, 1.0)) if status == "Completed" else int(committed * rng.uniform(0.1, 0.5)))})
for pid in sorted(first_start.index):              # historical sprints before the existing ones
    starts, s = [], first_start[pid] - timedelta(days=14)
    while s >= date(2025, 6, 2):
        starts.append(s); s -= timedelta(days=14)
    for i, st in enumerate(sorted(starts)):
        add_sprint(f"{spr_prefix[pid]}-SPR-H{i + 1:02d}", f"{pname[pid]} Sprint H{i + 1}", pid, st)
NEW_PROJECTS = {"1006": ("Cloud Migration", "CLD"), "1007": ("Analytics Platform", "ANL")}
for pid, (nm, k) in NEW_PROJECTS.items():
    pname[pid], key_of[pid], next_key[pid] = nm, k, 101
    st, i = date(2025, 6, 2), 1
    while st <= AS_OF:
        add_sprint(f"{k}-SPR-{i:02d}", f"{nm} Sprint {i}", pid, st); st += timedelta(days=14); i += 1
OUT2["jira_sprints"] = pd.DataFrame(spr_rows)[jira_sprints.columns]
sprints = pd.concat([sprints, OUT2["jira_sprints"].assign(s=lambda x: x.start_date.map(d), e=lambda x: x.end_date.map(d))], ignore_index=True)

PROJECTS2 = {"data": ["1002", "1001", "1003", "1007"], "software": ["1004", "1005", "1001", "1003", "1006"]}
devs2 = all2[all2.family.isin(["data", "software"])]
new_dev_ids = sorted(set(devs2.employee_id) - prior_ids)
overloaded2 = set(rng.choice(new_dev_ids, size=5, replace=False)) | overloaded
dev_pool = devs2[devs2.employment_status == "Active"]
issues2, wls2 = [], []
next_issue, next_wl = 70001, 980001
for _, e in devs2.iterrows():
    start = max(H_START, d(e.joining_date))
    end = date(2025, 12, 31) if e.employee_id in prior_ids else (date(2026, 6, 30) if e.employment_status == "Inactive" else AS_OF)
    if start > end:
        continue
    my_projects = list(rng.choice(PROJECTS2[e.family], size=int(rng.integers(1, 4)), replace=False))
    heavy = e.employee_id in overloaded2
    for m0, m1 in months(start, end):
        for _ in range(int(rng.poisson(2.6 * SEASON[m0.month] * (1.9 if heavy else 1.0)))):
            pid = choice(my_projects)
            created = rdate(m0, m1)
            age = (AS_OF - created).days
            if heavy and age <= 60:
                status = choice(["Done", "In Progress", "To Do", "Blocked"], p=[0.4, 0.27, 0.15, 0.18])
            elif age <= 14:
                status = choice(["To Do", "In Progress", "Blocked", "Done"], p=[0.4, 0.4, 0.08, 0.12])
            elif age <= 120:
                status = choice(["Done", "In Progress", "To Do", "Blocked"], p=[0.8, 0.1, 0.04, 0.06])
            else:
                status = choice(["Done", "In Progress", "To Do", "Blocked"], p=[0.94, 0.03, 0.01, 0.02])
            sp = sprint_for(pid, created)
            itype = choice(["Story", "Task", "Bug", "Epic"], p=[0.4, 0.3, 0.25, 0.05])
            resolved = min(created + timedelta(days=int(rng.integers(1, 16))), AS_OF) if status == "Done" else None
            updated = resolved or rdate(created, min(AS_OF, created + timedelta(days=60)))
            obj, verb = choice(OBJS), choice(VERBS)
            key = f"{key_of[pid]}-{next_key[pid]}"; next_key[pid] += 1
            issue = {"issue_id": str(next_issue), "issue_key": key, "project_id": pid, "project_name": pname[pid],
                "summary": f"{verb} {obj}", "description": f"Synthetic demo description (batch02): {verb.lower()} {obj}.",
                "issue_type": itype, "priority": choice(["Medium", "High", "Low", "Highest"], p=[0.45, 0.27, 0.2, 0.08]),
                "status": status, "assignee_id": e.employee_id, "assignee_name": e.employee_name,
                "reporter_id": choice(list(dev_pool.employee_id) + [e.manager_id]), "created_date": str(created), "updated_date": str(updated),
                "due_date": str(sp.e), "resolved_date": str(resolved) if resolved else "",
                "story_points": str(choice([13, 21]) if itype == "Epic" else choice([1, 2, 3, 5, 8, 13], p=[0.15, 0.2, 0.25, 0.22, 0.13, 0.05])),
                "sprint_id": sp.sprint_id, "labels": choice(labels_pool),
                "resolution": ("Fixed" if itype == "Bug" else "Done") if status == "Done" else "Unresolved"}
            issues2.append(issue); next_issue += 1
            if status == "To Do":
                continue
            wend = resolved or min(AS_OF, created + timedelta(days=45))
            for _ in range(int(rng.integers(1, 6 if heavy else 4))):
                author = e if rng.random() < 0.85 else dev_pool.sample(1, random_state=int(rng.integers(10**9))).iloc[0]
                wday = rdate(created, wend)
                stt = rts(wday, 19, 24) if rng.random() < (0.35 if heavy else 0.07) else rts(wday, 9, 18)
                wls2.append({"worklog_id": str(next_wl), "issue_id": issue["issue_id"], "employee_id": author.employee_id,
                    "employee_name": author.employee_name, "work_date": str(wday),
                    "time_spent_hours": str(choice([0.5, 1.0, 1.5, 2.0, 3.0, 4.0, 6.0, 8.0], p=[0.1, 0.15, 0.15, 0.2, 0.15, 0.12, 0.08, 0.05])),
                    "work_description": f"Worked on {key} - {issue['summary'].lower()}", "created_date": str(wday), "work_start_time": fmt_ts(stt)})
                next_wl += 1
OUT2["jira_issues"] = pd.DataFrame(issues2)[jira_issues.columns]
OUT2["jira_worklogs"] = pd.DataFrame(wls2)[list(jira_worklogs.columns) + ["work_start_time"]]
print("sprints:", len(spr_rows), "| issues:", len(issues2), OUT2["jira_issues"].status.value_counts().to_dict(), "| worklogs:", len(wls2))

# COMMAND ----------

# DBTITLE 1,Batch 02 ServiceNow - incidents, requests, tasks
staff2 = {g: list(v) for g, v in group_staff.items()}
for e in new2[new2.employment_status != "Inactive"].itertuples():
    if e.job_title in TITLE_GROUP:
        staff2[TITLE_GROUP[e.job_title]].append(e.employee_id)
joined_on = dict(zip(all2.employee_id, all2.joining_date.map(d)))
name2 = dict(zip(all2.employee_id, all2.employee_name))
callers = list(all2[all2.employment_status != "Inactive"].employee_id)
busy2 = set(rng.choice(sorted(x for v in staff2.values() for x in v), size=4, replace=False)) | {busy_support}

def pick_staff(group, day):
    ok = [x for x in staff2.get(group) or staff2["Service Desk"] if joined_on.get(x, date(2000, 1, 1)) <= day]
    ok = ok or (staff2.get(group) or staff2["Service Desk"])
    heavy = [x for x in ok if x in busy2]
    return choice(heavy) if heavy and rng.random() < 0.3 else choice(ok)

inc2, req2, tsk2 = [], [], []
for i, (m0, m1) in enumerate(months(H_START, AS_OF)):
    for _ in range(int(180 * (1 + 0.03 * i) * SEASON[m0.month])):
        c = combos.iloc[int(rng.integers(len(combos)))]
        day = rdate(m0, m1)
        assignee = pick_staff(c.assignment_group, day)
        caller = choice(callers)
        pr = choice(["Low", "Medium", "High", "Critical"], p=[0.45, 0.35, 0.15, 0.05])
        opened = rts(day, 0, 24) if rng.random() < 0.2 else rts(day)
        hours = float(rng.lognormal(np.log(MEAN_H[pr] * (1.4 if assignee in busy2 else 1.0)), 0.7))
        resolved = opened + timedelta(hours=hours)
        if (AS_OF_END - opened).days < 3 and rng.random() < 0.6 or resolved > AS_OF_END:
            state, resolved, closed = choice(["New", "In Progress"]), None, None
        else:
            state = choice(["Closed", "Resolved"], p=[0.85, 0.15])
            closed = min(resolved + timedelta(hours=float(rng.uniform(12, 72))), AS_OF_END) if state == "Closed" else None
        elapsed = ((resolved or AS_OF_END) - opened).total_seconds() / 3600
        sla = ("Met" if elapsed <= SLA_H[pr] else "Breached") if (resolved or elapsed > SLA_H[pr]) else ""
        inc2.append({"incident_id": f"INC2002{len(inc2) + 1:05d}", "employee_id": caller, "employee_name": name2[caller],
            "assigned_to_id": assignee, "assigned_to_name": name2.get(assignee, ""), "assignment_group": c.assignment_group,
            "category": c.category, "subcategory": c.subcategory, "short_description": c.short_description,
            "description": f"Synthetic demo incident (batch02): user {name2[caller]} reports '{c.short_description.lower()}'.",
            "priority": pr, "urgency": pr_codes[pr]["urgency"], "impact": pr_codes[pr]["impact"], "state": state,
            "opened_date": fmt_ts(opened), "resolved_date": fmt_ts(resolved) if resolved else "", "closed_date": fmt_ts(closed) if closed else "",
            "resolution_time_hours": f"{hours:.2f}" if resolved else "", "reopen_count": str(choice([0, 1, 2], p=[0.9, 0.08, 0.02])),
            "sla_status": sla, "satisfaction_score": f"{choice([1, 2, 3, 4, 5], p=[0.05, 0.1, 0.25, 0.35, 0.25])}.0" if state == "Closed" and rng.random() < 0.6 else ""})
    for _ in range(int(110 * (1 + 0.02 * i) * SEASON[m0.month])):
        c = rcombos.iloc[int(rng.integers(len(rcombos)))]
        day = rdate(m0, m1)
        assignee, requester = pick_staff(c.assigned_group, day), choice(callers)
        rdt = rts(day)
        hours = float(rng.lognormal(np.log(30), 0.6))
        done = rdt + timedelta(hours=hours)
        if done > AS_OF_END:
            status, done = choice(["Work in Progress", "Pending Approval"], p=[0.8, 0.2]), None
            approval = "Pending" if status == "Pending Approval" else "Approved"
        else:
            status = choice(["Closed Complete", "Closed Rejected", "Closed Incomplete"], p=[0.86, 0.08, 0.06])
            approval = "Rejected" if status == "Closed Rejected" else "Approved"
        rid = f"RITM2003{len(req2) + 1:05d}"
        req2.append({"request_id": rid, "employee_id": requester, "request_type": c.request_type, "request_category": c.request_category,
            "requested_item": c.requested_item, "assigned_group": c.assigned_group, "assigned_to_id": assignee, "request_status": status,
            "request_date": fmt_ts(rdt), "approval_status": approval, "completion_date": fmt_ts(done) if done else "",
            "fulfillment_time_hours": f"{hours:.2f}" if done else ""})
        steps = ["Approval"] + list(rng.choice(["Provisioning", "Configuration", "Delivery", "Verification", "Procurement"], size=int(rng.integers(1, 3)), replace=False))
        t0 = rdt
        for k, ttype in enumerate(steps):
            created = t0 + timedelta(minutes=int(rng.integers(10, 240)))
            finished = created + timedelta(hours=float(rng.uniform(0.5, max(hours / len(steps), 1))))
            closed_req = status.startswith("Closed")
            tstatus = ("Closed Complete" if status != "Closed Incomplete" else "Closed Incomplete") if closed_req else ("Work in Progress" if k == len(steps) - 1 else "Closed Complete")
            if not closed_req and finished > AS_OF_END:
                tstatus = "Open"
            tsk2.append({"task_id": f"SCTASK3003{len(tsk2) + 1:06d}", "parent_request_id": rid,
                "assigned_to_id": pick_staff(c.assigned_group, day) if ttype == "Approval" else assignee, "employee_id": requester,
                "task_type": ttype, "task_status": tstatus, "priority": choice(["Medium", "High", "Low", "Critical"], p=[0.55, 0.2, 0.2, 0.05]),
                "created_date": fmt_ts(created), "completed_date": fmt_ts(min(finished, AS_OF_END)) if tstatus.startswith("Closed") else "",
                "work_notes": f"Synthetic demo task (batch02): {ttype.lower()} for {c.requested_item}"})
            t0 = created
OUT2["servicenow_incidents"] = pd.DataFrame(inc2)[servicenow_incidents.columns]
OUT2["servicenow_requests"] = pd.DataFrame(req2)[servicenow_requests.columns]
OUT2["servicenow_tasks"] = pd.DataFrame(tsk2)[servicenow_tasks.columns]
print("incidents:", len(inc2), "requests:", len(req2), "tasks:", len(tsk2))

# COMMAND ----------

# DBTITLE 1,Batch 02 LMS - learning activity and certifications
la2, ct2 = [], []
have2 = have | set(zip(OUT["lms_learning_activity"].employee_id, OUT["lms_learning_activity"].course_id))
held2 = set(held)
for _, e in all2.iterrows():
    is_new = e.employee_id not in prior_ids
    lo = max(date(2025, 1, 6), d(e.joining_date)) if is_new else date(2025, 1, 6)
    hi = (date(2026, 6, 30) if e.employment_status == "Inactive" else AS_OF) if is_new else date(2025, 11, 30)
    if lo > hi:
        continue
    fam_sk = set(FAMILY_SKILLS[family(e.job_title)])
    w = np.array([3.0 if s in fam_sk else (2.0 if m == "Mandatory" else 1.0) for s, m in zip(courses.skill_name, courses.mandatory_flag)])
    n = int(rng.poisson(7 if is_new else 3))
    for ci in rng.choice(len(courses), size=min(n, len(courses)), replace=False, p=w / w.sum()):
        c = courses.iloc[int(ci)]
        if (e.employee_id, c.course_id) in have2:
            continue
        have2.add((e.employee_id, c.course_id))
        enr = rdate(lo, hi)
        recent = (AS_OF - enr).days < 45
        status = choice(["Enrolled", "In Progress", "Completed"], p=[0.4, 0.45, 0.15] if recent else [0.08, 0.14, 0.78])
        dur = float(c.course_duration_hours)
        start = min(enr + timedelta(days=int(rng.integers(0, 10))), AS_OF) if status != "Enrolled" else None
        comp = start + timedelta(days=int(rng.integers(1, 31))) if status == "Completed" else None
        if comp and comp > AS_OF:
            status, comp = "In Progress", None
        prog = 100 if status == "Completed" else (int(rng.integers(10, 91)) if status == "In Progress" else 0)
        hrs = dur * rng.uniform(0.8, 1.4) if status == "Completed" else dur * prog / 100 * rng.uniform(0.8, 1.2)
        score = int(np.clip(rng.normal(78, 11), 35, 100)) if status == "Completed" else None
        la2.append({"learning_activity_id": f"LA2{len(la2) + 1:06d}", "employee_id": e.employee_id, "course_id": c.course_id,
            "enrollment_date": str(enr), "start_date": str(start) if start else "", "completion_date": str(comp) if comp else "",
            "learning_status": status, "progress_percentage": str(prog), "learning_hours": f"{hrs:.1f}",
            "assessment_score": str(score) if score is not None else "",
            "pass_status": ("Passed" if score >= 60 else "Failed") if score is not None else "Pending",
            "last_activity_date": str(comp or (rdate(start, AS_OF) if start else enr))})
    fam = family(e.job_title)
    p_cert = (0.7 if fam in ("data", "software") else 0.45) if is_new else 0.25
    for name in rng.choice(FAMILY_CERTS[fam], size=min(2 if is_new else 1, len(FAMILY_CERTS[fam])), replace=False):
        if rng.random() > p_cert or (e.employee_id, name) in held2:
            continue
        held2.add((e.employee_id, name)); prov, cat, yrs = CERTS[name]
        status = choice(["Active", "In Progress", "Expired"], p=[0.72, 0.2, 0.08])
        if status == "Active":
            iss = rdate(max(date(2025, 1, 1), d(e.joining_date)), hi); exp = date(iss.year + yrs, iss.month, min(iss.day, 28))
        elif status == "Expired":
            iss = rdate(date(2021, 1, 1), date(2023, 6, 30)); exp = date(iss.year + yrs, iss.month, min(iss.day, 28))
            if exp >= AS_OF: status = "Active"
        else:
            iss = exp = None
        ct2.append({"certification_id": f"CERT2{len(ct2) + 1:05d}", "employee_id": e.employee_id, "certification_name": name,
            "certification_provider": prov, "skill_category": cat, "issue_date": str(iss) if iss else "", "expiry_date": str(exp) if exp else "",
            "certification_status": status, "credential_id": f"{prov[:1]}-{int(rng.integers(100000, 999999))}" if iss else "",
            "verification_status": ("Verified" if rng.random() < 0.8 else "Pending") if iss else "Pending"})
OUT2["lms_learning_activity"] = pd.DataFrame(la2)[lms_learning_activity.columns]
OUT2["lms_certifications"] = pd.DataFrame(ct2)[lms_certifications.columns]
print("learning:", len(la2), OUT2["lms_learning_activity"].learning_status.value_counts().to_dict(),
      "| certifications:", len(ct2), OUT2["lms_certifications"].certification_status.value_counts().to_dict())

# COMMAND ----------

# DBTITLE 1,Batch 02 validate and write files
ids2 = set(all2.employee_id)
prev = {k: set(globals()[k][c]) | set(OUT.get(k, pd.DataFrame({c: []}))[c]) for k, c in [
    ("servicenow_incidents", "incident_id"), ("servicenow_requests", "request_id"), ("servicenow_tasks", "task_id"),
    ("lms_learning_activity", "learning_activity_id"), ("lms_certifications", "certification_id"), ("jira_worklogs", "worklog_id"),
    ("jira_issues", "issue_id"), ("jira_sprints", "sprint_id"), ("hr4u_performance_reviews", "review_id"), ("hr4u_employee_goals", "goal_id"),
    ("hr4u_employee_mobility", "mobility_id")]}
pk_of = dict([("servicenow_incidents", "incident_id"), ("servicenow_requests", "request_id"), ("servicenow_tasks", "task_id"),
    ("lms_learning_activity", "learning_activity_id"), ("lms_certifications", "certification_id"), ("jira_worklogs", "worklog_id"),
    ("jira_issues", "issue_id"), ("jira_sprints", "sprint_id"), ("hr4u_performance_reviews", "review_id"), ("hr4u_employee_goals", "goal_id"),
    ("hr4u_employee_mobility", "mobility_id"), ("hr4u_employees", "employee_id"), ("hr4u_employee_skills", "employee_skill_id"), ("hr4u_manager_access", "access_id")])
checks2 = {
    "employee refs": [(k, c) for k, df in OUT2.items() for c in df.columns
                      if c in ("employee_id", "assignee_id", "reporter_id", "assigned_to_id", "manager_id", "reviewer_id", "manager_employee_id")
                      and not set(x for x in df[c] if x).issubset(ids2)],
    "sprint refs": not set(OUT2["jira_issues"].sprint_id).issubset(set(sprints.sprint_id)),
    "worklog issue refs": not set(OUT2["jira_worklogs"].issue_id).issubset(set(OUT2["jira_issues"].issue_id)),
    "task request refs": not set(OUT2["servicenow_tasks"].parent_request_id).issubset(set(OUT2["servicenow_requests"].request_id)),
    "course refs": not set(OUT2["lms_learning_activity"].course_id).issubset(set(lms_courses.course_id)),
    "duplicate keys in batch02": [k for k, df in OUT2.items() if df[pk_of[k]].duplicated().any()],
    "keys collide with earlier data": [k for k, ks in prev.items() if k in OUT2 and set(OUT2[k][pk_of[k]]) & ks],
    "future dated activity": any(x > str(AS_OF) + " 23:59:59" for k, c in [("jira_issues", "resolved_date"), ("jira_worklogs", "work_date"),
        ("servicenow_incidents", "resolved_date"), ("lms_learning_activity", "completion_date")] for x in OUT2[k][c] if x),
}
bad2 = {k: v for k, v in checks2.items() if v}
assert not bad2, f"Batch 02 validation failed: {bad2}"

written2 = [(n, f"{n}_{BATCH2}.csv", len(df), write_if_changed(df, f"{SRC}/{n}_{BATCH2}.csv")) for n, df in OUT2.items()]
with open(f"{SRC}/README_{BATCH2}.txt", "w") as f:
    f.write(f"PulseForge SYNTHETIC demo data, {BATCH2} (dashboard scale-up), generated by 05_PulseForge_Synthetic_Data_Generator "
            f"(seed 20261119, history {H_START} to {AS_OF}). New ID ranges only; original and batch01 files unchanged.\n")
display(pd.DataFrame(written2, columns=["source", "file", "rows", "action"]))